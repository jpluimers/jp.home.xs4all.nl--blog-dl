using System;
using System.IO;

namespace bo.Text
{
    public abstract class BaseReencoder : BaseTextProcessor
    {

        public abstract DefaultToDefaultProcessor CreateProcessor();

        #region Specific encodings

        public virtual void Run(string inputEncodingName, string outputEncodingName)
        {
            SpecificToSpecificProcessor specificToSpecificProcessor = new SpecificToSpecificProcessor(inputEncodingName, outputEncodingName);
            Run(Console.OpenStandardInput(), Console.OpenStandardOutput(), specificToSpecificProcessor);
        }

        public virtual void Run(string inputEncodingName, string outputEncodingName, string inputFileName)
        {
            SpecificToSpecificProcessor specificToSpecificProcessor = new SpecificToSpecificProcessor(inputEncodingName, outputEncodingName);
            using (Stream inputStream = GetInputStream(inputFileName))
            {
                Run(inputStream, Console.OpenStandardOutput(), specificToSpecificProcessor);
            }
        }

        public virtual void Run(string inputEncodingName, string outputEncodingName, string inputFileName, string outputFileName)
        {
            SpecificToSpecificProcessor specificToSpecificProcessor = new SpecificToSpecificProcessor(inputEncodingName, outputEncodingName);
            using (Stream inputStream = GetInputStream(inputFileName))
            {
                using (Stream outputStream = GetOutputStream(outputFileName))
                {
                    Run(inputStream, outputStream, specificToSpecificProcessor);
                }
            }
        }

        #endregion

        public virtual void Run(string[] args)
        {
            Stream input;
            Stream output;

            if (args.Length > 0)
                input = GetInputStream(args[0]);
            else
                input = Console.OpenStandardInput();

            if (args.Length > 1)
                output = GetOutputStream(args[1]);
            else
                output = Console.OpenStandardOutput();

            try
            {
                Run(input, output);
            }
            finally
            {
                if (args.Length > 1)
                    output.Close();
                if (args.Length > 0)
                    input.Close();
            }
        }

        public virtual void Run(Stream input, Stream output)
        {
            DefaultToDefaultProcessor processor = CreateProcessor();
            Run(input, output, processor);
        }

        public virtual void Run(Stream input, Stream output, DefaultToDefaultProcessor processor)
        {
            processor.Process(input, output);
        }
    }
}