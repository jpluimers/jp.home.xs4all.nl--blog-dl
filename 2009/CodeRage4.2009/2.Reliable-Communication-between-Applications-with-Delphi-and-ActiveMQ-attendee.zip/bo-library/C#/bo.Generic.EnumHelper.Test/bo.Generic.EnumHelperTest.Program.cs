﻿using System;
using System.Collections.Generic;

namespace bo.Generic.EnumHelperTest
{
    class Program
    {
        public enum TrafficLightColors
        {
            Red,
            Yellow,
            Green
        }

        private static void ShowNormal()
        {
            Array values = Enum.GetValues(typeof(TrafficLightColors));
            TrafficLightColors[] colorsArray = (TrafficLightColors[])values;
            foreach (TrafficLightColors color in colorsArray)
                Console.WriteLine(color);
        }

        private static void ShowEnumHelper()
        {
            TrafficLightColors[] colorsArray = EnumHelper.EnumToArray<TrafficLightColors>();
            foreach (TrafficLightColors color in colorsArray)
                Console.WriteLine(color);

            List<TrafficLightColors> colorsList = EnumHelper.EnumToList<TrafficLightColors>();
            foreach (TrafficLightColors color in colorsList)
                Console.WriteLine(color);
        }

        static void Main(string[] args)
        {
            ShowNormal();
            ShowEnumHelper();
        }
    }
}
