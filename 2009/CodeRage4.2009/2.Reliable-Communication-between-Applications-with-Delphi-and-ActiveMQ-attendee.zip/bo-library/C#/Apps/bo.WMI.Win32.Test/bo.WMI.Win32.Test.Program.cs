using System;
using System.Collections.Generic;
using bo.WMI.CIM;
using bo.WMI.MSFT;
using bo.WMI.Win32;
using bo.WMI.WmiHelpers;

namespace bo.WMI.Win32.Test
{
    class Program
    {
        /*
         * not easy to make generic, as System.ComponentModel.Component does not have a GetInstances, nor has the <T>Collection inner type
        public static List<T> GetAll<T>()
            where T: System.ComponentModel.Component
        {
        }
         */

        private static void log(string description, string content)
        {
            Console.WriteLine("{0}={1}", description, content);
        }

        static void Main(string[] args)
        {
            {
                Console.WriteLine("CIM.Processors");

                List<bo.WMI.CIM.Processor> Processors = WmiHelpers.CIM.GetAllProcessors();
                foreach (bo.WMI.CIM.Processor Processor in Processors)
                {
                    log("Name", Processor.Name);
                    log("Description", Processor.Description);
                }
            }

            {
                Console.WriteLine("Win32.Processors");

                List<bo.WMI.Win32.Processor> Processors = WmiHelpers.Win32.GetAllProcessors();
                foreach (bo.WMI.Win32.Processor Processor in Processors)
                {
                    log("Name", Processor.Name);
                    log("Description", Processor.Description);
                }
            }

            Console.WriteLine("Shares");

            List<Share> shares = WmiHelpers.Win32.GetAllShares();
            foreach (Share share in shares)
            {
                log("Name", share.Name);
                log("Description", share.Description);
            }

            Console.ReadLine();
        }
    }
}
