using System;
using System.Collections.Generic;
using bo;

namespace bo.EnumHelperTest
{
    public enum TrafficLightColors
    {
        Red,
        Yellow,
        Green
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<TrafficLightColors> colors = bo.EnumHelper.EnumToList<TrafficLightColors>();
        }
    }
}
