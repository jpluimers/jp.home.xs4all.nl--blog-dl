using System;
using System.Collections.Generic;
using bo.WMI.Win32;

namespace bo.WMI.WmiHelpers
{
    public class Win32
    {

        public static List<Share> GetAllShares()
        {
            Share.ShareCollection shares =
                Share.GetInstances();
            return ShareList(shares);
        }

        public static List<Share> ShareList(Share.ShareCollection shares)
        {
            List<Share> result = new List<Share>();
            foreach (Share share in shares)
                result.Add(share);
            return result;
        }


        public static List<Processor> GetAllProcessors()
        {
            Processor.ProcessorCollection Processors =
                Processor.GetInstances();
            return ProcessorList(Processors);
        }

        public static List<Processor> ProcessorList(Processor.ProcessorCollection Processors)
        {
            List<Processor> result = new List<Processor>();
            foreach (Processor Processor in Processors)
                result.Add(Processor);
            return result;
        }

    }
}
