using System;
using System.Collections.Generic;
using bo.WMI.CIM;

namespace bo.WMI.WmiHelpers
{
    public class CIM
    {

        public static List<BootSAP> GetAllBootSAPs()
        {
            BootSAP.BootSAPCollection BootSAPs =
                BootSAP.GetInstances();
            return BootSAPList(BootSAPs);
        }

        public static List<BootSAP> BootSAPList(BootSAP.BootSAPCollection BootSAPs)
        {
            List<BootSAP> result = new List<BootSAP>();
            foreach (BootSAP BootSAP in BootSAPs)
                result.Add(BootSAP);
            return result;
        }


        public static List<Processor> GetAllProcessors()
        {
            Processor.ProcessorCollection Processors =
                Processor.GetInstances();
            return ProcessorList(Processors);
        }
        
        public static List<Processor> ProcessorList(Processor.ProcessorCollection Processors)
        {
            List<Processor> result = new List<Processor>();
            foreach (Processor Processor in Processors)
                result.Add(Processor);
            return result;
        }

    }
}
