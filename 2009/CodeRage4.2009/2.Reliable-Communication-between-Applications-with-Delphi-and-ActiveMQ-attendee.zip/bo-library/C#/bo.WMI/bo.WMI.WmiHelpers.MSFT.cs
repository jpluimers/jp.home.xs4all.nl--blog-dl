using System;
using System.Collections.Generic;
using bo.WMI.MSFT;

namespace bo.WMI.WmiHelpers
{
    public class MSFT
    {

        public static List<WmiCoreObject> GetAllWmiCoreObjects()
        {
            WmiCoreObject.WmiCoreObjectCollection WmiCoreObjects =
                WmiCoreObject.GetInstances();
            return WmiCoreObjectList(WmiCoreObjects);
        }

        public static List<WmiCoreObject> WmiCoreObjectList(WmiCoreObject.WmiCoreObjectCollection WmiCoreObjects)
        {
            List<WmiCoreObject> result = new List<WmiCoreObject>();
            foreach (WmiCoreObject WmiCoreObject in WmiCoreObjects)
                result.Add(WmiCoreObject);
            return result;
        }

    }
}
