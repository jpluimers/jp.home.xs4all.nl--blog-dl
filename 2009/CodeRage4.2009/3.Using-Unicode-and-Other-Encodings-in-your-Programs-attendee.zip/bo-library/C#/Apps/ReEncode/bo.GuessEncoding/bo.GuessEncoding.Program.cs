﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
using System.IO;
using bo.Text;

namespace bo.GuessEncoding
{
    class Program : BaseTextProcessor
    {
        static void Help()
        {
            Console.WriteLine("Syntax: {0} textFileName",
                AssemblyHelper.ExecutableName);
            Console.WriteLine("  checks if textFileName has any bytes with the high bit set");
        }

        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                if (args.Length < 1)
                    Help();
                else
                {
                    Program program = new Program();
                    using (Stream stream = Program.GetInputStream(args[0]))
                    {
                        byte[] buffer = new byte[1];
                        int bufferLength = buffer.Length;
                        int readLength = stream.Read(buffer, 0, bufferLength);
                        while (readLength == bufferLength)
                        {
                            byte buffer0 = buffer[0];
                            if (buffer0 > 127)
                            {
                                Console.WriteLine("high bit set on at least one character: {0:X}", buffer0);
                                return;
                            }
                            readLength = stream.Read(buffer, 0, bufferLength);
                        }
                    }
                }

            }
             
            finally
            {
                Console.Write("Press <Enter>");
                Console.ReadLine();
            }
        }

    }
}
