﻿using System;
using System.Collections.Generic;

namespace bo.Generic
{
    public class EnumHelper
    {
        public static T[] EnumToArray<T>()
        {
            Array values = Enum.GetValues(typeof(T));
            T[] result = (T[])values;
            return result;
        }

        public static List<T> EnumToList<T>()
        {
            T[] array = EnumToArray<T>();
            List<T> result = new List<T>(array);
            return result;
        }
    }
}