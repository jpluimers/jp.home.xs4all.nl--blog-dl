LS,


The archive both contains slides, samples and part of the bo library that we internally use.

All source code is copyright (c) 2009 by Jeroen Wiert Pluimers.
I have done my best to make it work as best as I can, but there are no warranties it works.

If you use any of the code, please let me know in advance.
I'm not going to charge you for it, but I like to know what kind of applications my code is used for.


Regards,


Jeroen W. Pluimers - principal consultant
better office benelux
Pyrenee�n 71
1060 NP  Amsterdam
The Netherlands
Tel: +31 (20) 620 83 72
Fax: +31 (20) 620 83 74
http://www.better-office.nl



