using System;
using System.IO;
using bo.Text;

namespace bo.utf82ascii
{

    class Program
    {

        [STAThread]
        static void Main(string[] args)
        {
            Stream input;
            Stream output;

            if (args.Length > 0)
                input = new FileStream(args[0], FileMode.Open, FileAccess.Read);
            else
                input = Console.OpenStandardInput();

            if (args.Length > 1)
                output = new FileStream(args[1], FileMode.OpenOrCreate, FileAccess.Write);
            else
                output = Console.OpenStandardOutput();

            Utf8ToAsciiProcessor newUtf8ToAsciiProcessor = new Utf8ToAsciiProcessor();
            newUtf8ToAsciiProcessor.Process(input, output);
        }
    }
}