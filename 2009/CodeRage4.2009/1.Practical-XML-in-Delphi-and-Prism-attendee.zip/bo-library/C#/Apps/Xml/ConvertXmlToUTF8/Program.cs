﻿using System;

namespace bo.Xml
{
    class ConvertXmlToUTF8
    {
        static void Main(string[] args)
        {
            const string encoding = "UTF-8";
            ConvertXmlFilesToNewEncoding(args, encoding);
        }

        private static void ConvertXmlFilesToNewEncoding(string[] args, string encoding)
        {
            string prefix = encoding + "-";
            Console.WriteLine("Convert xml-files in arguments to {0} encoding and prefix {1} to each output xml file.", encoding, prefix);
            try
            {
                foreach (string arg in args)
                {
                    bo.Xml.XmlTranscoder.ConvertXmlFileToNewEncoding(arg, encoding, prefix);
                }
            }
            catch (Exception error)
            {
                Console.WriteLine(error.ToString());
            }
        }
    }
}
