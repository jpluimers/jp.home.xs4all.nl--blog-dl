LS,


The sources work in in Delphi Win32 2010 and Delphi Prism 2010.
They are likely to work in the Delphi 2009 counterparts as well.
Most of the Win32 code will work in Delphi 2007, and bits might work in Delphi 7 or earlier.

Have a lot of fun and let me know what you are using it for!



Regards,


Jeroen W. Pluimers - principal consultant
better office benelux
Pyrenee�n 71
1060 NP  Amsterdam
The Netherlands
Tel: +31 (20) 620 83 72
Fax: +31 (20) 620 83 74
http://www.better-office.nl



