﻿using System;
using System.Drawing;

namespace bo.Drawing
{
    public class RectangleHelper
    {
        // voorbeeld van een Generic method
        public static T[] Ordered<T>(T a, T b) where T: IComparable
        {
            T[] result = new T[2];
            if (a.CompareTo(b) < 0) // met inet kan dit simpeler: if (a < b)
            {
                result[0] = a;
                result[1] = b;
            }
            else
            {
                result[0] = b;
                result[1] = a;
            }
            return result;
        }

        // kan niet als een Extension method, want dat zijn altijd instance methods
        public static Rectangle Rectangle(Point a, Point b)
        {
            // gebruik van een Generic method
            int[] horizontal = Ordered(a.X, b.X); // no need for Ordered<int> as this is implied
            int[] vertical = Ordered(a.Y, b.Y);
            Rectangle result = System.Drawing.Rectangle.FromLTRB(
                horizontal[0], vertical[0], 
                horizontal[1], vertical[1]);
            return result;
        }
    }

}
