﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bo.Windows.Forms
{
    public class MouseEventArgsHelper
    {
        public static bool IsButtonPressed(MouseButtons button, MouseEventArgs e)
        {
            bool result = ((e.Button & button) == button);
            return result;
        }

        public static bool IsAnyOftheseButtonsPressed(MouseButtons button, MouseEventArgs e)
        {
            bool result = ((e.Button & button) != 0);
            return result;
        }
    }

    public static class MouseEventArgsExtension
    {
        public static bool IsButtonPressed(this MouseEventArgs e, System.Windows.Forms.MouseButtons button)
        {
            bool result = MouseEventArgsHelper.IsButtonPressed(button, e);
            return result;
        }

        public static bool IsAnyOftheseButtonsPressed(this MouseEventArgs e, System.Windows.Forms.MouseButtons button)
        {
            bool result = MouseEventArgsHelper.IsAnyOftheseButtonsPressed(button, e);
            return result;
        }
    }
}
