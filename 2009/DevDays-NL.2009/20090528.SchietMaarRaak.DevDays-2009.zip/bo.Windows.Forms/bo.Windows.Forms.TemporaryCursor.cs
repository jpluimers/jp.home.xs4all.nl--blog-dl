﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace bo.Windows.Forms
{
    public class TemporaryCursor : IDisposable
    {
        private System.Windows.Forms.Control targetControl;
        private System.Windows.Forms.Cursor savedCursor;

        public TemporaryCursor(System.Windows.Forms.Control targetControl, System.Windows.Forms.Cursor temporaryCursor)
        {
            this.targetControl = targetControl;
            this.savedCursor = targetControl.Cursor;
            targetControl.Cursor = temporaryCursor;
            targetControl.HandleDestroyed += new EventHandler(targetControl_HandleDestroyed);
        }

        void targetControl_HandleDestroyed(object sender, EventArgs e)
        {
            this.targetControl = null;
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (null != this.targetControl)
            {
                this.targetControl.Cursor = savedCursor;
                this.targetControl = null;
            }
        }

        ~TemporaryCursor()
        {
            this.Dispose(false);
        }

    }

}
