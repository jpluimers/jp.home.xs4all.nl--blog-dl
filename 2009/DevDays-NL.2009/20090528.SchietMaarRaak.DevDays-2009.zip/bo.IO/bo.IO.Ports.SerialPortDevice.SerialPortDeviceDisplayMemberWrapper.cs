﻿using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using bo.IO.Ports;

namespace bo.IO.Ports
{

    public class SerialPortDeviceDisplayMemberWrapper<T>
        where T: SerialPortDevice
    {
        public SerialPortDeviceDisplayMemberWrapper(T device)
            : base()
        {
            this.device = device;
        }

        public override string ToString()
        {
            return device.FriendlyName;
        }

        private T device;
        public T Device
        {
            get { return device; }
            //set { device = value; }
        }

    }
}
