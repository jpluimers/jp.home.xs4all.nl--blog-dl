﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

using System.IO.Ports;
using System.Security.Permissions;

using Microsoft.Win32;


namespace bo.IO.Ports
{
    /// <summary>
    /// SerialPortDevices Enumerates the ports from the registry
    /// </summary>
    public class SerialPortDevice
    {
        #region private fields

        private string _class;
        private string deviceDesc;
        private string deviceKeyName;
        private string friendlyName;
        private string mfg;
        private string portName;
        private string service;
        private string upperFilters;

        #endregion

        protected SerialPortDevice(RegistryKey deviceKey)
        {
            this.deviceKeyName = deviceKey.Name;
            string HKLM_BackSlash = combinePath(HKLM, "");
            if (DeviceKeyName.StartsWith(HKLM_BackSlash))
                this.deviceKeyName = this.deviceKeyName.Replace(HKLM_BackSlash, "");

            object _class = deviceKey.GetValue("Class"); // do not translate
            this._class = this.objectToString(_class);

            object deviceDesc = deviceKey.GetValue("DeviceDesc"); // do not translate
            this.deviceDesc = this.objectToString(deviceDesc);

            object friendlyName = deviceKey.GetValue("FriendlyName"); // do not translate
            this.friendlyName = this.objectToString(friendlyName);

            object mfg = deviceKey.GetValue("Mfg"); // do not translate
            this.mfg = this.objectToString(mfg);

            using (RegistryKey deviceParametersKey = deviceKey.OpenSubKey("Device Parameters")) // do not translate
            {
                if (null != deviceParametersKey)
                {
                    object portName = deviceParametersKey.GetValue("PortName"); // do not translate
                    this.portName = this.objectToString(portName);
                }
            }

            object upperFilters = deviceKey.GetValue("UpperFilters"); // do not translate
            this.upperFilters = this.objectToString(upperFilters);

            object service = deviceKey.GetValue("Service"); // do not translate
            this.service = this.objectToString(service);
        }

        private static string combinePath(string prefix, string suffix)
        {
            string result = string.Format(@"{0}\{1}",  // do not translate
                prefix, suffix);
            return result;
        }

        protected static string HKLM = @"HKEY_LOCAL_MACHINE"; // do not translate

        private static List<SerialPortDevice> getAllDevices()
        {
            List<SerialPortDevice> result = new List<SerialPortDevice>();
            string enumKeyName = @"SYSTEM\CurrentControlSet\Enum"; // do not translate
            string HKLMEnumerationPathList = combinePath(HKLM, enumKeyName);
            RegistryPermission HKLMEnumerationRegistryPermission = new RegistryPermission(RegistryPermissionAccess.Read, HKLMEnumerationPathList);
            HKLMEnumerationRegistryPermission.Assert();
            try
            {
                using (RegistryKey localMachine = Registry.LocalMachine)
                {
                    using (RegistryKey deviceClassesEnumerationKey = localMachine.OpenSubKey(enumKeyName, false))
                    {
                        if (null != deviceClassesEnumerationKey)
                        {
                            string[] deviceClassesSubKeyNames = deviceClassesEnumerationKey.GetSubKeyNames();
                            foreach (string deviceClassSubKeyName in deviceClassesSubKeyNames)
                            {
                                string deviceClassKeyName = combinePath(enumKeyName, deviceClassSubKeyName);
                                using (RegistryKey deviceSubClassesEnumerationKey = localMachine.OpenSubKey(deviceClassKeyName))
                                {
                                    if (null != deviceSubClassesEnumerationKey)
                                    {
                                        string[] deviceSubClassesSubKeyNames = deviceSubClassesEnumerationKey.GetSubKeyNames();
                                        foreach (string deviceSubClassSubKeyName in deviceSubClassesSubKeyNames)
                                        {
                                            string deviceSubClassKeyName = combinePath(deviceClassKeyName, deviceSubClassSubKeyName);
                                            using (RegistryKey devicesEnumerationKey = localMachine.OpenSubKey(deviceSubClassKeyName))
                                            {
                                                if (null != devicesEnumerationKey)
                                                {
                                                    string[] devicesSubKeyNames = devicesEnumerationKey.GetSubKeyNames();
                                                    foreach (string deviceSubKeyName in devicesSubKeyNames)
                                                    {
                                                        string deviceKeyName = combinePath(deviceSubClassKeyName, deviceSubKeyName);
                                                        using (RegistryKey deviceKey = localMachine.OpenSubKey(deviceKeyName))
                                                        {
                                                            SerialPortDevice device = new SerialPortDevice(deviceKey);
                                                            result.Add(device);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        return result;
                    }
                }
            }
            finally
            {
                RegistryPermission.RevertAssert(); // of HKLMEnumerationRegistryPermission.RevertAssert();
            }
        }

        public static List<SerialPortDevice> GetSerialPortDevices()
        {
            List<SerialPortDevice> result = new List<SerialPortDevice>();
            string[] portNames = GetSerialPortNames();
            List<SerialPortDevice> devices = getAllDevices();
            foreach (SerialPortDevice device in devices)
            {
                if (null != device.PortName)
                    if (-1 != Array.IndexOf<string>(portNames, device.PortName))
                        if (("Ports" == device.Class) || ("serenum" == device.UpperFilters)) // do not translate
                        {
                            result.Add(device);
                        }
            }
            return result;
        }

        public static string[] GetSerialPortNames()
        {
            return SerialPort.GetPortNames();
        }

        #region ToString

        private string objectToString(object value)
        {
            if (null == value)
            {
                return string.Empty;
            }
            if (value is Array)
            {
                StringBuilder result = new StringBuilder();
                foreach (object item in value as Array)
                {
                    if (0 != result.Length)
                    {
                        result.Append(Environment.NewLine);
                    }
                    result.Append(this.objectToString(item));
                }
                return result.ToString();
            }
            return value.ToString();
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();
            result.Append(string.Format("{0}={1}", "DeviceKey", this.DeviceKeyName));
            result.Append(string.Format("; {0}={1}", "Class", this.Class));
            result.Append(string.Format("; {0}={1}", "DeviceDesc", this.DeviceDesc));
            result.Append(string.Format("; {0}={1}", "FriendlyName", this.FriendlyName));
            result.Append(string.Format("; {0}={1}", "Mfg", this.Mfg));
            result.Append(string.Format("; {0}={1}", "PortName", this.PortName));
            result.Append(string.Format("; {0}={1}", "UpperFilters", this.UpperFilters));
            result.Append(string.Format("; {0}={1}", "Service", this.Service));
            return result.ToString();
        }

        #endregion ToString

        #region public Properties

        public string Class
        {
            get
            {
                return this._class;
            }
        }

        public string DeviceDesc
        {
            get
            {
                return this.deviceDesc;
            }
        }

        public string DeviceKeyName
        {
            get
            {
                return this.deviceKeyName;
            }
        }

        public string FriendlyName
        {
            get
            {
                return this.friendlyName;
            }
        }

        public string Mfg
        {
            get
            {
                return this.mfg;
            }
        }

        public string PortName
        {
            get
            {
                return this.portName;
            }
        }

        public string Service
        {
            get
            {
                return this.service;
            }
        }

        public string UpperFilters
        {
            get
            {
                return this.upperFilters;
            }
        }

        #endregion

    }
}