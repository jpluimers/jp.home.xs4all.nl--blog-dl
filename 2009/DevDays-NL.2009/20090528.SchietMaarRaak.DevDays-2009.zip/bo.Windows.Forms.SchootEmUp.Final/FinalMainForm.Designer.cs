﻿namespace bo.Windows.Forms.SchootEmUp.Base
{
    partial class FinalMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.targetPictureBox = new System.Windows.Forms.PictureBox();
            this.exceptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.playSoundBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.horizontalDomainNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.verticalDomainNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.videoGroupBox = new System.Windows.Forms.GroupBox();
            this.autoFireCheckBox = new System.Windows.Forms.CheckBox();
            this.highlightMotionRegionsCheckBox = new System.Windows.Forms.CheckBox();
            this.selectMotionDetectionAlgorithmSourceButton = new System.Windows.Forms.Button();
            this.motionDetectionAlgorithmTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.selectVideoSourceButton = new System.Windows.Forms.Button();
            this.videoDeviceNameTextBox = new System.Windows.Forms.TextBox();
            this.cameraWindow = new AForge.Camera.CameraWindow();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.statusBar = new System.Windows.Forms.StatusStrip();
            this.fpsLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.objectsCountLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.laserOnOffDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.pololuSpeedDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.maximumVerticalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.minimumVerticalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.maximumHorizontalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.minimumHorizontalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.comPortSettingsUserControl = new bo.Windows.Forms.UserControls.ComPortSettingsUserControl();
            this.viewPortGroupBox = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.viewPortBottomNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.viewPortRightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.viewPortTopNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.viewPortLeftNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.differenceThresholdDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            ((System.ComponentModel.ISupportInitialize)(this.targetPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizontalDomainNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.verticalDomainNumericUpDown)).BeginInit();
            this.videoGroupBox.SuspendLayout();
            this.statusBar.SuspendLayout();
            this.viewPortGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortBottomNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortRightNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortTopNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortLeftNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // targetPictureBox
            // 
            this.targetPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.targetPictureBox.Location = new System.Drawing.Point(12, 123);
            this.targetPictureBox.Name = "targetPictureBox";
            this.targetPictureBox.Size = new System.Drawing.Size(360, 225);
            this.targetPictureBox.TabIndex = 1;
            this.targetPictureBox.TabStop = false;
            this.targetPictureBox.DoubleClick += new System.EventHandler(this.targetPictureBox_DoubleClick);
            this.targetPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.targetPictureBox_MouseMove);
            this.targetPictureBox.Click += new System.EventHandler(this.targetPictureBox_Click);
            this.targetPictureBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.targetPictureBox_MouseDown);
            this.targetPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.targetPictureBox_Paint);
            this.targetPictureBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.targetPictureBox_MouseUp);
            // 
            // exceptionRichTextBox
            // 
            this.exceptionRichTextBox.ForeColor = System.Drawing.Color.Red;
            this.exceptionRichTextBox.Location = new System.Drawing.Point(12, 574);
            this.exceptionRichTextBox.Name = "exceptionRichTextBox";
            this.exceptionRichTextBox.ReadOnly = true;
            this.exceptionRichTextBox.Size = new System.Drawing.Size(360, 80);
            this.exceptionRichTextBox.TabIndex = 28;
            this.exceptionRichTextBox.Text = "test";
            this.exceptionRichTextBox.Visible = false;
            // 
            // playSoundBackgroundWorker
            // 
            this.playSoundBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.playSoundBackgroundWorker_DoWork);
            this.playSoundBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.playSoundBackgroundWorker_RunWorkerCompleted);
            // 
            // horizontalDomainNumericUpDown
            // 
            this.horizontalDomainNumericUpDown.Location = new System.Drawing.Point(244, 82);
            this.horizontalDomainNumericUpDown.Maximum = new decimal(new int[] {
            5500,
            0,
            0,
            0});
            this.horizontalDomainNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.horizontalDomainNumericUpDown.Name = "horizontalDomainNumericUpDown";
            this.horizontalDomainNumericUpDown.ReadOnly = true;
            this.horizontalDomainNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.horizontalDomainNumericUpDown.TabIndex = 31;
            this.horizontalDomainNumericUpDown.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // verticalDomainNumericUpDown
            // 
            this.verticalDomainNumericUpDown.Location = new System.Drawing.Point(302, 82);
            this.verticalDomainNumericUpDown.Maximum = new decimal(new int[] {
            5500,
            0,
            0,
            0});
            this.verticalDomainNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.verticalDomainNumericUpDown.Name = "verticalDomainNumericUpDown";
            this.verticalDomainNumericUpDown.ReadOnly = true;
            this.verticalDomainNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.verticalDomainNumericUpDown.TabIndex = 32;
            this.verticalDomainNumericUpDown.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // videoGroupBox
            // 
            this.videoGroupBox.Controls.Add(this.autoFireCheckBox);
            this.videoGroupBox.Controls.Add(this.highlightMotionRegionsCheckBox);
            this.videoGroupBox.Controls.Add(this.selectMotionDetectionAlgorithmSourceButton);
            this.videoGroupBox.Controls.Add(this.motionDetectionAlgorithmTextBox);
            this.videoGroupBox.Controls.Add(this.label6);
            this.videoGroupBox.Controls.Add(this.label5);
            this.videoGroupBox.Controls.Add(this.selectVideoSourceButton);
            this.videoGroupBox.Controls.Add(this.videoDeviceNameTextBox);
            this.videoGroupBox.Location = new System.Drawing.Point(378, 12);
            this.videoGroupBox.Name = "videoGroupBox";
            this.videoGroupBox.Size = new System.Drawing.Size(400, 105);
            this.videoGroupBox.TabIndex = 33;
            this.videoGroupBox.TabStop = false;
            this.videoGroupBox.Text = "Video:";
            // 
            // autoFireCheckBox
            // 
            this.autoFireCheckBox.AutoSize = true;
            this.autoFireCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.autoFireCheckBox.Location = new System.Drawing.Point(183, 76);
            this.autoFireCheckBox.Name = "autoFireCheckBox";
            this.autoFireCheckBox.Size = new System.Drawing.Size(180, 17);
            this.autoFireCheckBox.TabIndex = 7;
            this.autoFireCheckBox.Text = "Auto-fire at largest moving object";
            this.autoFireCheckBox.UseVisualStyleBackColor = true;
            this.autoFireCheckBox.CheckedChanged += new System.EventHandler(this.autoFireCheckBox_CheckedChanged);
            // 
            // highlightMotionRegionsCheckBox
            // 
            this.highlightMotionRegionsCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.highlightMotionRegionsCheckBox.Location = new System.Drawing.Point(9, 76);
            this.highlightMotionRegionsCheckBox.Name = "highlightMotionRegionsCheckBox";
            this.highlightMotionRegionsCheckBox.Size = new System.Drawing.Size(154, 17);
            this.highlightMotionRegionsCheckBox.TabIndex = 6;
            this.highlightMotionRegionsCheckBox.Text = "Highlight Motion Regions";
            this.highlightMotionRegionsCheckBox.UseVisualStyleBackColor = true;
            this.highlightMotionRegionsCheckBox.CheckedChanged += new System.EventHandler(this.highlightMotionRegionsCheckBox_CheckedChanged);
            // 
            // selectMotionDetectionAlgorithmSourceButton
            // 
            this.selectMotionDetectionAlgorithmSourceButton.Location = new System.Drawing.Point(369, 48);
            this.selectMotionDetectionAlgorithmSourceButton.Name = "selectMotionDetectionAlgorithmSourceButton";
            this.selectMotionDetectionAlgorithmSourceButton.Size = new System.Drawing.Size(25, 23);
            this.selectMotionDetectionAlgorithmSourceButton.TabIndex = 5;
            this.selectMotionDetectionAlgorithmSourceButton.Text = "...";
            this.selectMotionDetectionAlgorithmSourceButton.UseVisualStyleBackColor = true;
            this.selectMotionDetectionAlgorithmSourceButton.Click += new System.EventHandler(this.selectMotionDetectionAlgorithmSourceButton_Click);
            // 
            // motionDetectionAlgorithmTextBox
            // 
            this.motionDetectionAlgorithmTextBox.Location = new System.Drawing.Point(149, 50);
            this.motionDetectionAlgorithmTextBox.Name = "motionDetectionAlgorithmTextBox";
            this.motionDetectionAlgorithmTextBox.ReadOnly = true;
            this.motionDetectionAlgorithmTextBox.Size = new System.Drawing.Size(214, 20);
            this.motionDetectionAlgorithmTextBox.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Motion Detection Algorithm:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Video Camera Source:";
            // 
            // selectVideoSourceButton
            // 
            this.selectVideoSourceButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.selectVideoSourceButton.Location = new System.Drawing.Point(369, 19);
            this.selectVideoSourceButton.Name = "selectVideoSourceButton";
            this.selectVideoSourceButton.Size = new System.Drawing.Size(25, 23);
            this.selectVideoSourceButton.TabIndex = 2;
            this.selectVideoSourceButton.Text = "...";
            this.selectVideoSourceButton.UseVisualStyleBackColor = true;
            this.selectVideoSourceButton.Click += new System.EventHandler(this.selectVideoSourceButton_Click);
            // 
            // videoDeviceNameTextBox
            // 
            this.videoDeviceNameTextBox.Location = new System.Drawing.Point(149, 21);
            this.videoDeviceNameTextBox.Name = "videoDeviceNameTextBox";
            this.videoDeviceNameTextBox.ReadOnly = true;
            this.videoDeviceNameTextBox.Size = new System.Drawing.Size(214, 20);
            this.videoDeviceNameTextBox.TabIndex = 1;
            // 
            // cameraWindow
            // 
            this.cameraWindow.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cameraWindow.Camera = null;
            this.cameraWindow.Location = new System.Drawing.Point(378, 354);
            this.cameraWindow.Name = "cameraWindow";
            this.cameraWindow.Size = new System.Drawing.Size(400, 300);
            this.cameraWindow.TabIndex = 34;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // statusBar
            // 
            this.statusBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fpsLabel,
            this.objectsCountLabel});
            this.statusBar.Location = new System.Drawing.Point(0, 671);
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(902, 22);
            this.statusBar.TabIndex = 35;
            // 
            // fpsLabel
            // 
            this.fpsLabel.AutoSize = false;
            this.fpsLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.fpsLabel.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.fpsLabel.Name = "fpsLabel";
            this.fpsLabel.Size = new System.Drawing.Size(150, 17);
            this.fpsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // objectsCountLabel
            // 
            this.objectsCountLabel.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right)
                        | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.objectsCountLabel.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenInner;
            this.objectsCountLabel.Name = "objectsCountLabel";
            this.objectsCountLabel.Size = new System.Drawing.Size(737, 17);
            this.objectsCountLabel.Spring = true;
            this.objectsCountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // laserOnOffDomainSliderUserControl
            // 
            this.laserOnOffDomainSliderUserControl.DomainDescription = "Laser on-off";
            this.laserOnOffDomainSliderUserControl.DomainInitialValue = ((long)(3375));
            this.laserOnOffDomainSliderUserControl.DomainMaximumValue = ((long)(3450));
            this.laserOnOffDomainSliderUserControl.DomainMinimumValue = ((long)(3250));
            this.laserOnOffDomainSliderUserControl.DomainName = "Domain";
            this.laserOnOffDomainSliderUserControl.DomainValue = ((long)(3375));
            this.laserOnOffDomainSliderUserControl.Location = new System.Drawing.Point(12, 464);
            this.laserOnOffDomainSliderUserControl.Name = "laserOnOffDomainSliderUserControl";
            this.laserOnOffDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.laserOnOffDomainSliderUserControl.TabIndex = 27;
            this.laserOnOffDomainSliderUserControl.DomainValueChanged += new System.EventHandler(this.laserOnOffDomainSliderUserControl_DomainValueChanged);
            // 
            // pololuSpeedDomainSliderUserControl
            // 
            this.pololuSpeedDomainSliderUserControl.DomainDescription = "Pololu protocol servo speed";
            this.pololuSpeedDomainSliderUserControl.DomainInitialValue = ((long)(30));
            this.pololuSpeedDomainSliderUserControl.DomainMaximumValue = ((long)(127));
            this.pololuSpeedDomainSliderUserControl.DomainMinimumValue = ((long)(0));
            this.pololuSpeedDomainSliderUserControl.DomainName = "Pololu Speed";
            this.pololuSpeedDomainSliderUserControl.DomainValue = ((long)(30));
            this.pololuSpeedDomainSliderUserControl.Location = new System.Drawing.Point(198, 464);
            this.pololuSpeedDomainSliderUserControl.Name = "pololuSpeedDomainSliderUserControl";
            this.pololuSpeedDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.pololuSpeedDomainSliderUserControl.TabIndex = 22;
            // 
            // maximumVerticalDomainSliderUserControl
            // 
            this.maximumVerticalDomainSliderUserControl.DomainDescription = "Maximum vertical";
            this.maximumVerticalDomainSliderUserControl.DomainInitialValue = ((long)(4200));
            this.maximumVerticalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.maximumVerticalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.maximumVerticalDomainSliderUserControl.DomainName = "Domain";
            this.maximumVerticalDomainSliderUserControl.DomainValue = ((long)(4200));
            this.maximumVerticalDomainSliderUserControl.Location = new System.Drawing.Point(378, 244);
            this.maximumVerticalDomainSliderUserControl.Name = "maximumVerticalDomainSliderUserControl";
            this.maximumVerticalDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.maximumVerticalDomainSliderUserControl.TabIndex = 5;
            // 
            // minimumVerticalDomainSliderUserControl
            // 
            this.minimumVerticalDomainSliderUserControl.DomainDescription = "Minimum vertical";
            this.minimumVerticalDomainSliderUserControl.DomainInitialValue = ((long)(1600));
            this.minimumVerticalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.minimumVerticalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.minimumVerticalDomainSliderUserControl.DomainName = "Domain";
            this.minimumVerticalDomainSliderUserControl.DomainValue = ((long)(1600));
            this.minimumVerticalDomainSliderUserControl.Location = new System.Drawing.Point(378, 123);
            this.minimumVerticalDomainSliderUserControl.Name = "minimumVerticalDomainSliderUserControl";
            this.minimumVerticalDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.minimumVerticalDomainSliderUserControl.TabIndex = 4;
            // 
            // maximumHorizontalDomainSliderUserControl
            // 
            this.maximumHorizontalDomainSliderUserControl.DomainDescription = "Maximum horizontal";
            this.maximumHorizontalDomainSliderUserControl.DomainInitialValue = ((long)(4700));
            this.maximumHorizontalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.maximumHorizontalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.maximumHorizontalDomainSliderUserControl.DomainName = "Domain";
            this.maximumHorizontalDomainSliderUserControl.DomainValue = ((long)(4700));
            this.maximumHorizontalDomainSliderUserControl.Location = new System.Drawing.Point(198, 354);
            this.maximumHorizontalDomainSliderUserControl.Name = "maximumHorizontalDomainSliderUserControl";
            this.maximumHorizontalDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.maximumHorizontalDomainSliderUserControl.TabIndex = 3;
            // 
            // minimumHorizontalDomainSliderUserControl
            // 
            this.minimumHorizontalDomainSliderUserControl.DomainDescription = "Minimum horizontal";
            this.minimumHorizontalDomainSliderUserControl.DomainInitialValue = ((long)(750));
            this.minimumHorizontalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.minimumHorizontalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.minimumHorizontalDomainSliderUserControl.DomainName = "Domain";
            this.minimumHorizontalDomainSliderUserControl.DomainValue = ((long)(750));
            this.minimumHorizontalDomainSliderUserControl.Location = new System.Drawing.Point(12, 354);
            this.minimumHorizontalDomainSliderUserControl.Name = "minimumHorizontalDomainSliderUserControl";
            this.minimumHorizontalDomainSliderUserControl.Size = new System.Drawing.Size(174, 104);
            this.minimumHorizontalDomainSliderUserControl.TabIndex = 2;
            // 
            // comPortSettingsUserControl
            // 
            this.comPortSettingsUserControl.Location = new System.Drawing.Point(12, 12);
            this.comPortSettingsUserControl.Name = "comPortSettingsUserControl";
            this.comPortSettingsUserControl.Size = new System.Drawing.Size(360, 104);
            this.comPortSettingsUserControl.TabIndex = 0;
            // 
            // viewPortGroupBox
            // 
            this.viewPortGroupBox.Controls.Add(this.label4);
            this.viewPortGroupBox.Controls.Add(this.label3);
            this.viewPortGroupBox.Controls.Add(this.viewPortBottomNumericUpDown);
            this.viewPortGroupBox.Controls.Add(this.viewPortRightNumericUpDown);
            this.viewPortGroupBox.Controls.Add(this.label2);
            this.viewPortGroupBox.Controls.Add(this.viewPortTopNumericUpDown);
            this.viewPortGroupBox.Controls.Add(this.viewPortLeftNumericUpDown);
            this.viewPortGroupBox.Controls.Add(this.label1);
            this.viewPortGroupBox.Location = new System.Drawing.Point(558, 248);
            this.viewPortGroupBox.Name = "viewPortGroupBox";
            this.viewPortGroupBox.Size = new System.Drawing.Size(220, 100);
            this.viewPortGroupBox.TabIndex = 36;
            this.viewPortGroupBox.TabStop = false;
            this.viewPortGroupBox.Text = "View port:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(169, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Y";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(104, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "X";
            // 
            // viewPortBottomNumericUpDown
            // 
            this.viewPortBottomNumericUpDown.Location = new System.Drawing.Point(155, 58);
            this.viewPortBottomNumericUpDown.Maximum = new decimal(new int[] {
            0,
            1,
            0,
            0});
            this.viewPortBottomNumericUpDown.Name = "viewPortBottomNumericUpDown";
            this.viewPortBottomNumericUpDown.ReadOnly = true;
            this.viewPortBottomNumericUpDown.Size = new System.Drawing.Size(59, 20);
            this.viewPortBottomNumericUpDown.TabIndex = 5;
            // 
            // viewPortRightNumericUpDown
            // 
            this.viewPortRightNumericUpDown.Location = new System.Drawing.Point(90, 58);
            this.viewPortRightNumericUpDown.Maximum = new decimal(new int[] {
            0,
            1,
            0,
            0});
            this.viewPortRightNumericUpDown.Name = "viewPortRightNumericUpDown";
            this.viewPortRightNumericUpDown.ReadOnly = true;
            this.viewPortRightNumericUpDown.Size = new System.Drawing.Size(59, 20);
            this.viewPortRightNumericUpDown.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Bottom Right";
            // 
            // viewPortTopNumericUpDown
            // 
            this.viewPortTopNumericUpDown.Location = new System.Drawing.Point(155, 32);
            this.viewPortTopNumericUpDown.Maximum = new decimal(new int[] {
            0,
            1,
            0,
            0});
            this.viewPortTopNumericUpDown.Name = "viewPortTopNumericUpDown";
            this.viewPortTopNumericUpDown.ReadOnly = true;
            this.viewPortTopNumericUpDown.Size = new System.Drawing.Size(59, 20);
            this.viewPortTopNumericUpDown.TabIndex = 2;
            // 
            // viewPortLeftNumericUpDown
            // 
            this.viewPortLeftNumericUpDown.Location = new System.Drawing.Point(90, 32);
            this.viewPortLeftNumericUpDown.Maximum = new decimal(new int[] {
            0,
            1,
            0,
            0});
            this.viewPortLeftNumericUpDown.Name = "viewPortLeftNumericUpDown";
            this.viewPortLeftNumericUpDown.ReadOnly = true;
            this.viewPortLeftNumericUpDown.Size = new System.Drawing.Size(59, 20);
            this.viewPortLeftNumericUpDown.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Top Left";
            // 
            // differenceThresholdDomainSliderUserControl
            // 
            this.differenceThresholdDomainSliderUserControl.DomainDescription = "Difference Threshold";
            this.differenceThresholdDomainSliderUserControl.DomainInitialValue = ((long)(100));
            this.differenceThresholdDomainSliderUserControl.DomainMaximumValue = ((long)(255));
            this.differenceThresholdDomainSliderUserControl.DomainMinimumValue = ((long)(0));
            this.differenceThresholdDomainSliderUserControl.DomainName = "Domain";
            this.differenceThresholdDomainSliderUserControl.DomainValue = ((long)(100));
            this.differenceThresholdDomainSliderUserControl.Location = new System.Drawing.Point(604, 123);
            this.differenceThresholdDomainSliderUserControl.Name = "differenceThresholdDomainSliderUserControl";
            this.differenceThresholdDomainSliderUserControl.Size = new System.Drawing.Size(174, 105);
            this.differenceThresholdDomainSliderUserControl.TabIndex = 37;
            this.differenceThresholdDomainSliderUserControl.DomainValueChanged += new System.EventHandler(this.differenceThresholdDomainSliderUserControl_DomainValueChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 693);
            this.Controls.Add(this.differenceThresholdDomainSliderUserControl);
            this.Controls.Add(this.viewPortGroupBox);
            this.Controls.Add(this.statusBar);
            this.Controls.Add(this.cameraWindow);
            this.Controls.Add(this.videoGroupBox);
            this.Controls.Add(this.verticalDomainNumericUpDown);
            this.Controls.Add(this.horizontalDomainNumericUpDown);
            this.Controls.Add(this.exceptionRichTextBox);
            this.Controls.Add(this.laserOnOffDomainSliderUserControl);
            this.Controls.Add(this.pololuSpeedDomainSliderUserControl);
            this.Controls.Add(this.maximumVerticalDomainSliderUserControl);
            this.Controls.Add(this.minimumVerticalDomainSliderUserControl);
            this.Controls.Add(this.maximumHorizontalDomainSliderUserControl);
            this.Controls.Add(this.minimumHorizontalDomainSliderUserControl);
            this.Controls.Add(this.targetPictureBox);
            this.Controls.Add(this.comPortSettingsUserControl);
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.targetPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizontalDomainNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.verticalDomainNumericUpDown)).EndInit();
            this.videoGroupBox.ResumeLayout(false);
            this.videoGroupBox.PerformLayout();
            this.statusBar.ResumeLayout(false);
            this.statusBar.PerformLayout();
            this.viewPortGroupBox.ResumeLayout(false);
            this.viewPortGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortBottomNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortRightNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortTopNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewPortLeftNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private bo.Windows.Forms.UserControls.ComPortSettingsUserControl comPortSettingsUserControl;
        private System.Windows.Forms.PictureBox targetPictureBox;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl minimumHorizontalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl maximumHorizontalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl maximumVerticalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl minimumVerticalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl pololuSpeedDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl laserOnOffDomainSliderUserControl;
        private System.Windows.Forms.RichTextBox exceptionRichTextBox;
        private System.ComponentModel.BackgroundWorker playSoundBackgroundWorker;
        private System.Windows.Forms.NumericUpDown horizontalDomainNumericUpDown;
        private System.Windows.Forms.NumericUpDown verticalDomainNumericUpDown;
        private System.Windows.Forms.GroupBox videoGroupBox;
        private System.Windows.Forms.Button selectVideoSourceButton;
        private System.Windows.Forms.TextBox videoDeviceNameTextBox;
        private AForge.Camera.CameraWindow cameraWindow;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.StatusStrip statusBar;
        private System.Windows.Forms.ToolStripStatusLabel fpsLabel;
        private System.Windows.Forms.ToolStripStatusLabel objectsCountLabel;
        private System.Windows.Forms.GroupBox viewPortGroupBox;
        private System.Windows.Forms.NumericUpDown viewPortBottomNumericUpDown;
        private System.Windows.Forms.NumericUpDown viewPortRightNumericUpDown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown viewPortTopNumericUpDown;
        private System.Windows.Forms.NumericUpDown viewPortLeftNumericUpDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button selectMotionDetectionAlgorithmSourceButton;
        private System.Windows.Forms.TextBox motionDetectionAlgorithmTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox highlightMotionRegionsCheckBox;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl differenceThresholdDomainSliderUserControl;
        private System.Windows.Forms.CheckBox autoFireCheckBox;
    }
}

