﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Threading;

using bo.IO.Pololu;
using AForge.Camera;
using AForge.Video;
using AForge.Video.DirectShow;
using AForge.Video.Local;
using AForge.Vision.Motion;
using AForge.Vision.Local;

namespace bo.Windows.Forms.SchootEmUp.Base
{
    public partial class FinalMainForm : Form
    {
        #region Construction

        ServoController servoController = new ServoController(); //create an instance of our class so we can access its functions

        public FinalMainForm()
        {
            InitializeComponent();
            lastMouseDownLocation = new Point(targetPictureBox.Width / 10, targetPictureBox.Height / 10);
            lastMouseLocation = new Point(targetPictureBox.Width / 2, targetPictureBox.Height / 2);
            lastMouseUpLocation = new Point((9 * targetPictureBox.Width) / 10, (9 * targetPictureBox.Height) / 10);
            MoveLaserToCurrentPosition();
        }

        #endregion

        #region Pololu handling

        private const int servoPortHorizontal = 0;
        private const int servoPortVertical = 1;
        private const int servoPortLaser = 2;

        public void sendPololu(int servoPort, int servoPosition, int servoSpeed)
        {
            try
            {
                string comPort = comPortSettingsUserControl.SelectedComPort;
                int baudRate = comPortSettingsUserControl.SelectedBaudRate;
                servoController.Pololu(comPort, baudRate, servoPort, servoPosition, servoSpeed);
            }
            catch (Exception ex)
            {
                exceptionRichTextBox.Text = ex.ToString();
                exceptionRichTextBox.Visible = true;
            }
        }

        #endregion

        #region Control key handling

        private bool lastAnyControlKeyDown = false;

        private void setLastAnyControlKeyDown()
        {
            lastAnyControlKeyDown = (ModifierKeys & Keys.Control) == Keys.Control;
        }

        #endregion

        #region Laser handling

        public bool LaserOn
        {
            get
            {
                return laserOnOffDomainSliderUserControl.DomainMaximumValue == laserOnOffDomainSliderUserControl.DomainValue;
            }
            set
            {
                if (value != LaserOn)
                    if (value)
                    {
                        setLaserOn();
                        if (lastAnyControlKeyDown)
                            startPlayingLaserSound();
                    }
                    else
                    {
                        setLaserOff();
                    }
            }
        }

        private void setLaserOff()
        {
            laserOnOffDomainSliderUserControl.DomainValue = laserOnOffDomainSliderUserControl.DomainMinimumValue;
        }

        private void setLaserOn()
        {
            laserOnOffDomainSliderUserControl.DomainValue = laserOnOffDomainSliderUserControl.DomainMaximumValue;
        }

        public void setLaser(int laserValue)
        {
            exceptionRichTextBox.Visible = false;
            int servoSpeed = 127; // always fastest speed!
            sendPololu(servoPortLaser, laserValue, servoSpeed);
        }

        private void setLaser()
        {
            if (comPortSettingsUserControl.HasValidComPortSettings)
            {
                int laserValue = (int)(laserOnOffDomainSliderUserControl.DomainValue);
                setLaser(laserValue);
            }
        }

        private void startPlayingLaserSound()
        {
            if (!playSoundBackgroundWorker.IsBusy)
                playSoundBackgroundWorker.RunWorkerAsync();
        }

        private static void playLaserSound()
        {
            // note: SoundPlayer can ONLY play PCM WAV files (no mp3, and no non-PCM WAV files)!
            using (System.Media.SoundPlayer soundPlayer = new System.Media.SoundPlayer("GunShot1.wav")) // TODO convert to const
            {
                soundPlayer.PlaySync();
            }
        }

        #endregion

        #region MousePosition handling

        private Point lastMouseDownLocation = new Point(0, 0);
        private Point lastMouseLocation = new Point(0, 0);
        private Point lastMouseUpLocation = new Point(0, 0);

        public Point LastMouseUpLocation
        {
            get { return lastMouseUpLocation; }
            set { lastMouseUpLocation = value; }
        }

        public Rectangle ViewPort
        {
            get
            {
                Rectangle result = bo.Drawing.RectangleHelper.Rectangle(lastMouseDownLocation, lastMouseUpLocation);
                viewPortTopNumericUpDown.Value = result.Top;
                viewPortBottomNumericUpDown.Value = result.Bottom;
                viewPortLeftNumericUpDown.Value = result.Left;
                viewPortRightNumericUpDown.Value = result.Right;
                return result;
            }
        }

        private Point ShootPosition
        {
            get
            {
                Point locationInTargetPictureBox = this.lastMouseLocation;
                Point result = TransformToShootPosition(locationInTargetPictureBox);
                return result;
            }
        }

        private Point TransformToShootPosition(Point locationInTargetPictureBox)
        {
            long horizontalScale = maximumHorizontalDomainSliderUserControl.DomainValue - minimumHorizontalDomainSliderUserControl.DomainValue;
            long horizontalPosition = (locationInTargetPictureBox.X * horizontalScale) / targetPictureBox.Width;
            horizontalPosition += minimumHorizontalDomainSliderUserControl.DomainValue;

            long verticalScale = maximumVerticalDomainSliderUserControl.DomainValue - minimumVerticalDomainSliderUserControl.DomainValue;
            long verticalPosition = (locationInTargetPictureBox.Y * verticalScale) / targetPictureBox.Height;
            verticalPosition += minimumVerticalDomainSliderUserControl.DomainValue;

            horizontalDomainNumericUpDown.Value = verticalPosition;
            horizontalDomainNumericUpDown.Value = horizontalPosition;

            Point result = new Point((int)horizontalPosition, (int)verticalPosition);
            return result;
        }

        private void MoveLaserToCurrentPosition()
        {
            if (comPortSettingsUserControl.HasValidComPortSettings)
            {
                exceptionRichTextBox.Visible = false;
                MoveLaserToPosition(ShootPosition);
            }
        }

        private void MoveLaserToPosition(Point shootPosition)
        {
            int servoSpeed = Convert.ToInt32(pololuSpeedDomainSliderUserControl.DomainValue);
            sendPololu(servoPortHorizontal, shootPosition.X, servoSpeed);
            sendPololu(servoPortVertical, shootPosition.Y, servoSpeed);
        }

        private void updateLastMouseLocation(MouseEventArgs e)
        {
            int horizontal = targetPictureBox.Width - e.X; // invert horizontal
            int vertical = e.Y; //targetPictureBox.Height - e.Y; // invert vertical
            lastMouseLocation = new Point(horizontal, vertical);
        }

        #endregion

        #region Event handlers

        private void targetPictureBox_Click(object sender, EventArgs e)
        {
            MoveLaserToCurrentPosition();
        }

        private void targetPictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            updateLastMouseLocation(e);
            //if (bo.Windows.Forms.MouseEventArgsHelper.IsButtonPressed(MouseButtons.Left, e))
            if (e.IsAnyOftheseButtonsPressed(MouseButtons.Left | MouseButtons.Right))
                MoveLaserToCurrentPosition();
        }

        private void targetPictureBox_DoubleClick(object sender, EventArgs e)
        {
            LaserOn = !LaserOn;
        }

        private void laserOnOffDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            setLaser();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            setLaserOff();
        }

        private void playSoundBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            playLaserSound();
        }

        private void playSoundBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            setLaserOff();
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            // in order to receive this event on the Form level, you must set KeyPreview = true;
            setLastAnyControlKeyDown();
        }

        private void MainForm_KeyUp(object sender, KeyEventArgs e)
        {
            // in order to receive this event on the Form level, you must set KeyPreview = true;
            setLastAnyControlKeyDown();
        }

        #endregion

        #region Video handling

        // opened video source
        private IVideoSource videoSource = null;
        // motion detector
        private IMotionDetector detector = null;

        // statistics length
        private const int statLength = 15;
        // current statistics index
        private int statIndex = 0;
        // ready statistics values
        private int statReady = 0;
        // statistics array
        private int[] statCount = new int[statLength];

        private void selectVideoSource()
        {
            VideoCaptureDeviceForm form = new VideoCaptureDeviceForm();

            if (form.ShowDialog(this) == DialogResult.OK)
            {
                // create video source
                VideoCaptureDevice videoSource = new VideoCaptureDevice(form.VideoDeviceMoniker);
                videoDeviceNameTextBox.Text = form.VideoDeviceName;

                // open it
                OpenVideoSource(videoSource);
            }
        }

        // Close current video source
        private void CloseVideoSource()
        {
            Camera camera = cameraWindow.Camera;

            if (camera != null)
            {
                // stop timer
                timer.Stop();

                // detach camera from camera window
                cameraWindow.Camera = null;
                camera.NewFrame -= new EventHandler(camera_NewFrame);
                Application.DoEvents();

                // signal camera to stop
                camera.SignalToStop();
                // wait 2 seconds until camera stops
                for (int i = 0; (i < 20) && (camera.IsRunning); i++)
                {
                    Thread.Sleep(100);
                }
                if (camera.IsRunning)
                    camera.Stop();
                camera = null;

                // reset motion detector
                if (detector != null)
                    detector.Reset();

                videoSource = null;
            }
        }

        // Open video source
        private void OpenVideoSource(IVideoSource source)
        {
            // set busy cursor
            using (TemporaryCursor waitCursor = new TemporaryCursor(this, Cursors.WaitCursor))
            {
                // close previous video source
                CloseVideoSource();

                // create camera
                Camera camera = new Camera(source, detector);
                camera.NewFrame += new EventHandler(camera_NewFrame);
                // start camera
                camera.Start();

                // attach camera to camera window
                cameraWindow.Camera = camera;

                // reset statistics
                statIndex = statReady = 0;

                // start timer
                timer.Start();

                videoSource = source;
            }
        }

        private void gatherStatistics()
        {
            Camera camera = cameraWindow.Camera;

            if (camera != null)
            {
                // get number of frames for the last second
                statCount[statIndex] = camera.FramesReceived;

                // increment indexes
                if (++statIndex >= statLength)
                    statIndex = 0;
                if (statReady < statLength)
                    statReady++;

                float fps = 0;

                // calculate average value
                for (int i = 0; i < statReady; i++)
                {
                    fps += statCount[i];
                }
                fps /= statReady;

                statCount[statIndex] = 0;

                fpsLabel.Text = string.Format("{0:F2} fps", fps);
            }
        }

        // On new frame
        private void camera_NewFrame(object sender, System.EventArgs e)
        {
            //// double-casting anti-pattern:

            //if (detector is ICountingMotionDetector)
            //{
            //    ICountingMotionDetector countingDetector = (ICountingMotionDetector)detector;
            //    objectsCountLabel.Text = string.Format("Objects: {0}", countingDetector.ObjectsCount);
            //}
            //else
            //    objectsCountLabel.Text = "";

            // single as-cast + null check pattern:

            ICountingMotionDetector countingDetector = detector as ICountingMotionDetector;
            if (null != countingDetector)
                objectsCountLabel.Text = string.Format("Objects: {0}", countingDetector.ObjectsCount);
            else
                objectsCountLabel.Text = "";
        }

        #endregion

        #region Motion Detection handling

        private bool autoFire;

        private void performAutoFire()
        {
            if (autoFire)
            {
                Point shootPosition = getShootPosition();
                if (Point.Empty != shootPosition)
                {
                    MoveLaserToPosition(shootPosition);
                    playLaserSound();
                    targetPictureBox.Invalidate();
                }
            }
        }

        private Point getShootPosition()
        {
            ICountingMotionDetector countingDetector = detector as ICountingMotionDetector;
            Point shootPosition = Point.Empty;
            if (null != countingDetector)
            {
                if (countingDetector.ObjectsCount > 0)
                {
                    IOrderedEnumerable<Rectangle> objectRectangles =
                        //countingDetector.ObjectRectangles.OrderByDescending<Rectangle, int>(rectangleSurfaceArea);
                        //countingDetector.ObjectRectangles.OrderByDescending(rectangle => rectangle.Width * rectangle.Height);
                        countingDetector.ObjectRectangles.OrderByDescending(rectangle => rectangle.SurfaceArea());
                    Rectangle largest = objectRectangles.First();
                    Point firePositionInCameraView = new Point(largest.Left + (largest.Width / 2), largest.Top + (largest.Height / 2));
                    Rectangle viewPort = ViewPort;
                    Point firePositionInViewPort = new Point(
                        (firePositionInCameraView.X * viewPort.Width) / cameraWindow.Width,
                        (firePositionInCameraView.Y * viewPort.Height) / cameraWindow.Height);
                    Point firePositionInTargetPictureBox = new Point(
                        firePositionInViewPort.X + viewPort.Left,
                        firePositionInViewPort.Y + viewPort.Top);
                    shootPosition = TransformToShootPosition(firePositionInTargetPictureBox);
                }
            }
            return shootPosition;
        }

        private int rectangleSurfaceArea(Rectangle rectangle)
        {
            return rectangle.Width * rectangle.Height;
        }

        private void selectMotionDetectionAlgorithm()
        {
            SelectMotionDetectionForm form = new SelectMotionDetectionForm();

            if (form.ShowDialog(this) == DialogResult.OK)
            {
                SetMotionDetector(null);
                IMotionDetector newMotionDetector = form.CreateMotionDetector();
                SetMotionDetector(newMotionDetector);
            }
        }

        private void SetMotionDetector(IMotionDetector detector)
        {
            // set the checkbox upfront so the event that fires does not need to do anything
            if (null == detector)
            {
                motionDetectionAlgorithmTextBox.Text = "none";
                highlightMotionRegionsCheckBox.Checked = false;
            }
            else
            {
                motionDetectionAlgorithmTextBox.Text = detector.GetType().Name;
                highlightMotionRegionsCheckBox.Checked = detector.HighlightMotionRegions;
            }

            this.detector = detector;

            // set motion detector to camera
            Camera camera = cameraWindow.Camera;

            if (camera != null)
            {
                camera.Lock();
                camera.MotionDetector = detector;

                // reset statistics
                statIndex = statReady = 0;
                camera.Unlock();
            }
        }

        private void SetHighlightMotionRegions(bool highlightMotionRegions)
        {
            // update motion detector
            Camera camera = cameraWindow.Camera;
            if (camera != null)
            {
                IMotionDetector detector = camera.MotionDetector;

                if (detector != null)
                    detector.HighlightMotionRegions = highlightMotionRegions;
            }
        }

        private void applyDifferenceThreshold()
        {
            CountingMotionDetector countingMotionDetector = detector as CountingMotionDetector;
            if (null != countingMotionDetector)
            {
                int differenceThreshold = (int)(differenceThresholdDomainSliderUserControl.DomainValue);
                countingMotionDetector.DifferenceThreshold = differenceThreshold;
            }
        }

        #endregion

        private void selectVideoSourceButton_Click(object sender, EventArgs e)
        {
            selectVideoSource();
        }

        // On timer event - gather statistics
        private void timer_Tick(object sender, EventArgs e)
        {
            gatherStatistics();
            performAutoFire();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseVideoSource();
        }

        private void targetPictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.IsButtonPressed(MouseButtons.Right))
                lastMouseDownLocation = new Point(e.X, e.Y);
        }

        private void targetPictureBox_Paint(object sender, PaintEventArgs e)
        {
            paintVideoViewPortInLaserArea(e);
        }

        private void paintVideoViewPortInLaserArea(PaintEventArgs e)
        {
            Brush fillBrush = Brushes.DimGray;
            Rectangle fillRectangle = ViewPort;
            e.Graphics.FillRectangle(fillBrush, fillRectangle);

            if (autoFire)
            {
                Point shootPosition = getShootPosition();
                fillBrush = Brushes.Red;
                fillRectangle.Location = shootPosition;
                fillRectangle.Width = 1;
                fillRectangle.Height = 1;
                fillRectangle.Inflate(3,3);
                e.Graphics.FillRectangle(fillBrush, fillRectangle);
            }
        }

        private void targetPictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            //if (bo.Windows.Forms.MouseEventArgsHelper.IsButtonPressed(MouseButtons.Right, e))
            if (e.IsButtonPressed(MouseButtons.Right))
                lastMouseUpLocation = new Point(e.X, e.Y);
            targetPictureBox.Refresh();
        }

        private void highlightMotionRegionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            SetHighlightMotionRegions(highlightMotionRegionsCheckBox.Checked);
        }

        private void selectMotionDetectionAlgorithmSourceButton_Click(object sender, EventArgs e)
        {
            selectMotionDetectionAlgorithm();
        }

        private void differenceThresholdDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            applyDifferenceThreshold();
        }

        private void autoFireCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            autoFire = autoFireCheckBox.Checked;
        }

    }
}

public static class RectangleExtension
{
    public static int SurfaceArea(this Rectangle rectangle)
    {
        return rectangle.Width * rectangle.Height;
    }
}
