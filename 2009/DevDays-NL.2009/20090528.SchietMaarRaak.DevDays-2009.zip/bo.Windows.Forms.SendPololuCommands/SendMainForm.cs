using System;
using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Text;
using System.Windows.Forms;

using System.IO.Ports;
using bo.IO.Ports;
using bo.IO.Pololu;

namespace bo.Windows.Forms.SendPololuCommands
{

    public partial class SendMainForm : Form
    {
        ServoController servoController = new ServoController(); //create an instance of our class so we can access its functions

        public SendMainForm()
        {
            InitializeComponent();
            fillServoPortComboBox();
        }

        private void fillServoPortComboBox()
        {
            servoPortComboBox.Items.Clear();
            for (int i = 0; i < 16; i++)
            {
                servoPortComboBox.Items.Add(i);
            }
            servoPortComboBox.SelectedIndex = 0;
        }

        private int selectedServoPort()
        {
            object servoPort = servoPortComboBox.SelectedItem;
            int result = (int)servoPort;
            return result;
        }

        private void sendMiniSSCCoordinate()
        {
            string comPort = comPortSettingsUserControl.SelectedComPort;
            int baudRate = comPortSettingsUserControl.SelectedBaudRate;
            int servoPort = selectedServoPort();
            int servoCoordinate = Convert.ToInt32(miniSSCCoordinateDomainSliderUserControl.DomainValue);

            //moves servo servoPort to the location in the text box via MiniSSC Mode.
            servoController.MiniSSC(comPort, baudRate, servoPort, servoCoordinate);
        }

        private void sendPololuCoordinate()
        {
            string comPort = comPortSettingsUserControl.SelectedComPort;
            int baudRate = comPortSettingsUserControl.SelectedBaudRate;
            int servoPort = selectedServoPort();

            int servoCoordinate = Convert.ToInt32(pololuCoordinateDomainSliderUserControl.DomainValue);
            //0 is quickest, 127 is slowest
            int servoSpeed = Convert.ToInt32(pololuSpeedDomainSliderUserControl.DomainValue);

            //this function will move servo servoPort, at the quickest speed, via a certain COMport and baud rate
            try
            {
                servoController.Pololu(comPort, baudRate, servoPort, servoCoordinate, servoSpeed);
                exceptionTextBox.Visible = false;
            }
            catch (Exception ex)
            {
                exceptionTextBox.Text = ex.ToString();
                exceptionTextBox.Visible = true;
            }
        }

        private void sendPololuCoordinateButton_Click(object sender, EventArgs e)
        {
            sendPololuCoordinate();
        }

        private void sendMiniSSCCoordinateButton_Click(object sender, EventArgs e)
        {
            sendMiniSSCCoordinate();
        }

        private void pololuCoordinateDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            sendPololuCoordinate();
        }

        private void pololuSpeedDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            sendPololuCoordinate();
        }

        private void miniSSCCoordinateDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            sendMiniSSCCoordinate();
        }

    }
}