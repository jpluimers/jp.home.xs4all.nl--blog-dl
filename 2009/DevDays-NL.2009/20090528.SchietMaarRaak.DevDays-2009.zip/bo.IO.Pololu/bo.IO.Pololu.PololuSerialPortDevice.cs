﻿//using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Microsoft.Win32;

using bo.IO.Ports;

namespace bo.IO.Pololu
{
    public class PololuSerialPortDevice : SerialPortDevice
    {
        protected PololuSerialPortDevice(RegistryKey deviceKey)
            : base(deviceKey)
        {
        }

        public const string PololuDeviceDesc = "Pololu USB-to-serial adapter"; // do not translate

        public static List<PololuSerialPortDevice> GetPololuSerialPortDevices()
        {
            List<PololuSerialPortDevice> result = new List<PololuSerialPortDevice>();
            List<bo.IO.Ports.SerialPortDevice> serialPortDevices = bo.IO.Ports.SerialPortDevice.GetSerialPortDevices();
            foreach (bo.IO.Ports.SerialPortDevice device in serialPortDevices)
            {
                switch (device.DeviceDesc)
                {
                    case PololuDeviceDesc:
                        using (RegistryKey localMachine = Registry.LocalMachine)
                        {
                            using (RegistryKey deviceKey = localMachine.OpenSubKey(device.DeviceKeyName))
                            {
                                PololuSerialPortDevice pololuSerialPortDevice = new PololuSerialPortDevice(deviceKey);
                                result.Add(pololuSerialPortDevice);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
            return result;
        }
    }
}