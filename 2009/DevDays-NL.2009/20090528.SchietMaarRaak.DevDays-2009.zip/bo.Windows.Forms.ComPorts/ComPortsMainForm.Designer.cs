﻿namespace bo.Windows.Forms.ComPorts
{
    partial class ComPortsMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enumPortsButton = new System.Windows.Forms.Button();
            this.enumDevicesButton = new System.Windows.Forms.Button();
            this.testPololuButton = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // enumPortsButton
            // 
            this.enumPortsButton.Location = new System.Drawing.Point(0, 0);
            this.enumPortsButton.Name = "enumPortsButton";
            this.enumPortsButton.Size = new System.Drawing.Size(75, 23);
            this.enumPortsButton.TabIndex = 0;
            this.enumPortsButton.Text = "enumPorts";
            this.enumPortsButton.UseVisualStyleBackColor = true;
            this.enumPortsButton.Click += new System.EventHandler(this.enumPortsButton_Click);
            // 
            // enumDevicesButton
            // 
            this.enumDevicesButton.Location = new System.Drawing.Point(81, 0);
            this.enumDevicesButton.Name = "enumDevicesButton";
            this.enumDevicesButton.Size = new System.Drawing.Size(75, 23);
            this.enumDevicesButton.TabIndex = 1;
            this.enumDevicesButton.Text = "enumDevices";
            this.enumDevicesButton.UseVisualStyleBackColor = true;
            this.enumDevicesButton.Click += new System.EventHandler(this.enumDevicesButton_Click);
            // 
            // testPololuButton
            // 
            this.testPololuButton.Enabled = false;
            this.testPololuButton.Location = new System.Drawing.Point(162, 0);
            this.testPololuButton.Name = "testPololuButton";
            this.testPololuButton.Size = new System.Drawing.Size(75, 23);
            this.testPololuButton.TabIndex = 2;
            this.testPololuButton.Text = "testPololu";
            this.testPololuButton.UseVisualStyleBackColor = true;
            this.testPololuButton.Click += new System.EventHandler(this.testPololuButton_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(243, 0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(0, 53);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(296, 222);
            this.textBox1.TabIndex = 4;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(0, 29);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(296, 21);
            this.comboBox1.TabIndex = 5;
            this.comboBox1.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.testPololuButton);
            this.Controls.Add(this.enumDevicesButton);
            this.Controls.Add(this.enumPortsButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button enumPortsButton;
        private System.Windows.Forms.Button enumDevicesButton;
        private System.Windows.Forms.Button testPololuButton;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

