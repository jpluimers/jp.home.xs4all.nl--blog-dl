﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using System.IO.Ports;
using bo.IO.Ports;

namespace bo.Windows.Forms.ComPorts
{
    public partial class ComPortsMainForm : Form
    {
        public ComPortsMainForm()
        {
            InitializeComponent();
            clearLog();
        }

        private void clearLog()
        {
            textBox1.Clear();
        }

        private void log(object value)
        {
            if (null == value)
                log("<<null>>");
            else
                textBox1.AppendText(value.ToString());
            textBox1.AppendText(Environment.NewLine);
        }

        private void enumPortsButton_Click(object sender, EventArgs e)
        {
            clearLog();
            string[] portNames = SerialPort.GetPortNames();
            foreach (string portName in portNames)
            {
                log(portName);
            }

            foreach (string portName in portNames)
            {
                using (SerialPort serialPort = new SerialPort(portName))
                {
                    log(serialPort);
                }
            }
        }

        private void enumDevicesButton_Click(object sender, EventArgs e)
        {
            enumPortsButton_Click(sender, e);
            comboBox1.Items.Clear();
            List<bo.IO.Ports.SerialPortDevice> devices = bo.IO.Ports.SerialPortDevice.GetSerialPortDevices();
            foreach (bo.IO.Ports.SerialPortDevice device in devices)
            {
                switch (device.DeviceDesc)
                {
                    case "Pololu USB-to-serial adapter": // do not translate
                        log(string.Format("{0}:{1}", device.Mfg, device.FriendlyName));
                        comboBox1.Items.Add(new SerialPortDeviceDisplayMemberWrapper<SerialPortDevice>(device));
                        break;
                    case "Crystalfontz CFA633-USB": // do not translate
                    case "Crystalfontz CFA635-USB": // do not translate
                        log(string.Format("{0}:{1}", device.Mfg, device.FriendlyName));
                        //comboBox1.Items.Add(new SerialPortDeviceDisplayMemberWrapper(device));
                        break;
                    case "USB Serial Port": // do not translate
                        log("Denon interface:" + device.FriendlyName);
                        break;
                    default:
                        break;
                }
            }
            if (0 < comboBox1.Items.Count)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> wrapper = SelectedSerialPortDeviceDisplayMemberWrapper();
            testPololuButton.Enabled = (null != wrapper);
        }

        private SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> SelectedSerialPortDeviceDisplayMemberWrapper()
        {
            object selectedItem = comboBox1.SelectedItem;
            SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> wrapper =
                (SerialPortDeviceDisplayMemberWrapper<SerialPortDevice>)selectedItem;
            return wrapper;
        }

        private void testPololuButton_Click(object sender, EventArgs e)
        {
            SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> wrapper = SelectedSerialPortDeviceDisplayMemberWrapper();
            if (null != wrapper)
            {
                //Lcd = new bo.IO.Crystalfontz.Cfa633Lcd(wrapper.Device);
            }
        }

    }
}
