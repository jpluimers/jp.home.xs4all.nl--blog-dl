﻿namespace bo.Windows.Forms.SchootEmUp.Base
{
    partial class BaseMainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.targetPictureBox = new System.Windows.Forms.PictureBox();
            this.laserOnOffDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.pololuSpeedDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.maximumVerticalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.minimumVerticalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.maximumHorizontalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.minimumHorizontalDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.comPortSettingsUserControl = new bo.Windows.Forms.UserControls.ComPortSettingsUserControl();
            this.exceptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.playSoundBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.horizontalDomainNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.verticalDomainNumericUpDown = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.targetPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizontalDomainNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.verticalDomainNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // targetPictureBox
            // 
            this.targetPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.targetPictureBox.Location = new System.Drawing.Point(12, 136);
            this.targetPictureBox.Name = "targetPictureBox";
            this.targetPictureBox.Size = new System.Drawing.Size(600, 375);
            this.targetPictureBox.TabIndex = 1;
            this.targetPictureBox.TabStop = false;
            this.targetPictureBox.DoubleClick += new System.EventHandler(this.targetPictureBox_DoubleClick);
            this.targetPictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.targetPictureBox_MouseMove);
            this.targetPictureBox.Click += new System.EventHandler(this.targetPictureBox_Click);
            // 
            // laserOnOffDomainSliderUserControl
            // 
            this.laserOnOffDomainSliderUserControl.DomainDescription = "Laser on-off";
            this.laserOnOffDomainSliderUserControl.DomainInitialValue = ((long)(3355));
            this.laserOnOffDomainSliderUserControl.DomainMaximumValue = ((long)(3410));
            this.laserOnOffDomainSliderUserControl.DomainMinimumValue = ((long)(3250));
            this.laserOnOffDomainSliderUserControl.DomainName = "Domain";
            this.laserOnOffDomainSliderUserControl.DomainValue = ((long)(3355));
            this.laserOnOffDomainSliderUserControl.Location = new System.Drawing.Point(618, 517);
            this.laserOnOffDomainSliderUserControl.Name = "laserOnOffDomainSliderUserControl";
            this.laserOnOffDomainSliderUserControl.Size = new System.Drawing.Size(253, 117);
            this.laserOnOffDomainSliderUserControl.TabIndex = 27;
            this.laserOnOffDomainSliderUserControl.DomainValueChanged += new System.EventHandler(this.laserOnOffDomainSliderUserControl_DomainValueChanged);
            // 
            // pololuSpeedDomainSliderUserControl
            // 
            this.pololuSpeedDomainSliderUserControl.DomainDescription = "Pololu protocol (no jumper) servo speed";
            this.pololuSpeedDomainSliderUserControl.DomainInitialValue = ((long)(30));
            this.pololuSpeedDomainSliderUserControl.DomainMaximumValue = ((long)(127));
            this.pololuSpeedDomainSliderUserControl.DomainMinimumValue = ((long)(0));
            this.pololuSpeedDomainSliderUserControl.DomainName = "Pololu Speed";
            this.pololuSpeedDomainSliderUserControl.DomainValue = ((long)(30));
            this.pololuSpeedDomainSliderUserControl.Location = new System.Drawing.Point(618, 12);
            this.pololuSpeedDomainSliderUserControl.Name = "pololuSpeedDomainSliderUserControl";
            this.pololuSpeedDomainSliderUserControl.Size = new System.Drawing.Size(253, 118);
            this.pololuSpeedDomainSliderUserControl.TabIndex = 22;
            // 
            // maximumVerticalDomainSliderUserControl
            // 
            this.maximumVerticalDomainSliderUserControl.DomainDescription = "Maximum vertical";
            this.maximumVerticalDomainSliderUserControl.DomainInitialValue = ((long)(4200));
            this.maximumVerticalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.maximumVerticalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.maximumVerticalDomainSliderUserControl.DomainName = "Domain";
            this.maximumVerticalDomainSliderUserControl.DomainValue = ((long)(4200));
            this.maximumVerticalDomainSliderUserControl.Location = new System.Drawing.Point(618, 394);
            this.maximumVerticalDomainSliderUserControl.Name = "maximumVerticalDomainSliderUserControl";
            this.maximumVerticalDomainSliderUserControl.Size = new System.Drawing.Size(253, 117);
            this.maximumVerticalDomainSliderUserControl.TabIndex = 5;
            // 
            // minimumVerticalDomainSliderUserControl
            // 
            this.minimumVerticalDomainSliderUserControl.DomainDescription = "Minimum vertical";
            this.minimumVerticalDomainSliderUserControl.DomainInitialValue = ((long)(1600));
            this.minimumVerticalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.minimumVerticalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.minimumVerticalDomainSliderUserControl.DomainName = "Domain";
            this.minimumVerticalDomainSliderUserControl.DomainValue = ((long)(1600));
            this.minimumVerticalDomainSliderUserControl.Location = new System.Drawing.Point(618, 136);
            this.minimumVerticalDomainSliderUserControl.Name = "minimumVerticalDomainSliderUserControl";
            this.minimumVerticalDomainSliderUserControl.Size = new System.Drawing.Size(253, 117);
            this.minimumVerticalDomainSliderUserControl.TabIndex = 4;
            // 
            // maximumHorizontalDomainSliderUserControl
            // 
            this.maximumHorizontalDomainSliderUserControl.DomainDescription = "Maximum horizontal";
            this.maximumHorizontalDomainSliderUserControl.DomainInitialValue = ((long)(4700));
            this.maximumHorizontalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.maximumHorizontalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.maximumHorizontalDomainSliderUserControl.DomainName = "Domain";
            this.maximumHorizontalDomainSliderUserControl.DomainValue = ((long)(4700));
            this.maximumHorizontalDomainSliderUserControl.Location = new System.Drawing.Point(359, 517);
            this.maximumHorizontalDomainSliderUserControl.Name = "maximumHorizontalDomainSliderUserControl";
            this.maximumHorizontalDomainSliderUserControl.Size = new System.Drawing.Size(253, 117);
            this.maximumHorizontalDomainSliderUserControl.TabIndex = 3;
            // 
            // minimumHorizontalDomainSliderUserControl
            // 
            this.minimumHorizontalDomainSliderUserControl.DomainDescription = "Minimum horizontal";
            this.minimumHorizontalDomainSliderUserControl.DomainInitialValue = ((long)(750));
            this.minimumHorizontalDomainSliderUserControl.DomainMaximumValue = ((long)(5500));
            this.minimumHorizontalDomainSliderUserControl.DomainMinimumValue = ((long)(500));
            this.minimumHorizontalDomainSliderUserControl.DomainName = "Domain";
            this.minimumHorizontalDomainSliderUserControl.DomainValue = ((long)(750));
            this.minimumHorizontalDomainSliderUserControl.Location = new System.Drawing.Point(12, 517);
            this.minimumHorizontalDomainSliderUserControl.Name = "minimumHorizontalDomainSliderUserControl";
            this.minimumHorizontalDomainSliderUserControl.Size = new System.Drawing.Size(253, 117);
            this.minimumHorizontalDomainSliderUserControl.TabIndex = 2;
            // 
            // comPortSettingsUserControl
            // 
            this.comPortSettingsUserControl.Location = new System.Drawing.Point(12, 12);
            this.comPortSettingsUserControl.Name = "comPortSettingsUserControl";
            this.comPortSettingsUserControl.Size = new System.Drawing.Size(376, 118);
            this.comPortSettingsUserControl.TabIndex = 0;
            // 
            // exceptionRichTextBox
            // 
            this.exceptionRichTextBox.ForeColor = System.Drawing.Color.Red;
            this.exceptionRichTextBox.Location = new System.Drawing.Point(394, 12);
            this.exceptionRichTextBox.Name = "exceptionRichTextBox";
            this.exceptionRichTextBox.ReadOnly = true;
            this.exceptionRichTextBox.Size = new System.Drawing.Size(218, 118);
            this.exceptionRichTextBox.TabIndex = 28;
            this.exceptionRichTextBox.Text = "test";
            this.exceptionRichTextBox.Visible = false;
            // 
            // playSoundBackgroundWorker
            // 
            this.playSoundBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.playSoundBackgroundWorker_DoWork);
            this.playSoundBackgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.playSoundBackgroundWorker_RunWorkerCompleted);
            // 
            // horizontalDomainNumericUpDown
            // 
            this.horizontalDomainNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.horizontalDomainNumericUpDown.Location = new System.Drawing.Point(271, 579);
            this.horizontalDomainNumericUpDown.Maximum = new decimal(new int[] {
            5500,
            0,
            0,
            0});
            this.horizontalDomainNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.horizontalDomainNumericUpDown.Name = "horizontalDomainNumericUpDown";
            this.horizontalDomainNumericUpDown.ReadOnly = true;
            this.horizontalDomainNumericUpDown.Size = new System.Drawing.Size(82, 20);
            this.horizontalDomainNumericUpDown.TabIndex = 31;
            this.horizontalDomainNumericUpDown.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // verticalDomainNumericUpDown
            // 
            this.verticalDomainNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.verticalDomainNumericUpDown.Location = new System.Drawing.Point(699, 316);
            this.verticalDomainNumericUpDown.Maximum = new decimal(new int[] {
            5500,
            0,
            0,
            0});
            this.verticalDomainNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.verticalDomainNumericUpDown.Name = "verticalDomainNumericUpDown";
            this.verticalDomainNumericUpDown.ReadOnly = true;
            this.verticalDomainNumericUpDown.Size = new System.Drawing.Size(82, 20);
            this.verticalDomainNumericUpDown.TabIndex = 32;
            this.verticalDomainNumericUpDown.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 673);
            this.Controls.Add(this.verticalDomainNumericUpDown);
            this.Controls.Add(this.horizontalDomainNumericUpDown);
            this.Controls.Add(this.exceptionRichTextBox);
            this.Controls.Add(this.laserOnOffDomainSliderUserControl);
            this.Controls.Add(this.pololuSpeedDomainSliderUserControl);
            this.Controls.Add(this.maximumVerticalDomainSliderUserControl);
            this.Controls.Add(this.minimumVerticalDomainSliderUserControl);
            this.Controls.Add(this.maximumHorizontalDomainSliderUserControl);
            this.Controls.Add(this.minimumHorizontalDomainSliderUserControl);
            this.Controls.Add(this.targetPictureBox);
            this.Controls.Add(this.comPortSettingsUserControl);
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.targetPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.horizontalDomainNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.verticalDomainNumericUpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private bo.Windows.Forms.UserControls.ComPortSettingsUserControl comPortSettingsUserControl;
        private System.Windows.Forms.PictureBox targetPictureBox;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl minimumHorizontalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl maximumHorizontalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl maximumVerticalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl minimumVerticalDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl pololuSpeedDomainSliderUserControl;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl laserOnOffDomainSliderUserControl;
        private System.Windows.Forms.RichTextBox exceptionRichTextBox;
        private System.ComponentModel.BackgroundWorker playSoundBackgroundWorker;
        private System.Windows.Forms.NumericUpDown horizontalDomainNumericUpDown;
        private System.Windows.Forms.NumericUpDown verticalDomainNumericUpDown;
    }
}

