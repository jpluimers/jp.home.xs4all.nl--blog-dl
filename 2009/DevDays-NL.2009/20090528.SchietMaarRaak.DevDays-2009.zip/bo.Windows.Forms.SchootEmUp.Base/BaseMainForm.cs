﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using bo.IO.Pololu;

namespace bo.Windows.Forms.SchootEmUp.Base
{
    public partial class BaseMainForm : Form
    {
        ServoController servoController = new ServoController(); //create an instance of our class so we can access its functions

        public BaseMainForm()
        {
            InitializeComponent();
            lastMouseDownLocation = new Point(targetPictureBox.Width / 2, targetPictureBox.Height / 2);
            ShootAtCurrentPosition();
        }

        private Point lastMouseDownLocation = new Point(0, 0);
        private bool lastAnyControlKeyDown = false;
        private const int servoPortHorizontal = 0;
        private const int servoPortVertical = 1;
        private const int servoPortLaser = 2;

        private Point ShootPosition
        {
            get
            {
                long horizontalScale = maximumHorizontalDomainSliderUserControl.DomainValue - minimumHorizontalDomainSliderUserControl.DomainValue;
                long horizontalPosition = (lastMouseDownLocation.X * horizontalScale) / targetPictureBox.Width;
                horizontalPosition += minimumHorizontalDomainSliderUserControl.DomainValue;

                long verticalScale = maximumVerticalDomainSliderUserControl.DomainValue - minimumVerticalDomainSliderUserControl.DomainValue;
                long verticalPosition = (lastMouseDownLocation.Y * verticalScale) / targetPictureBox.Height;
                verticalPosition += minimumVerticalDomainSliderUserControl.DomainValue;

                horizontalDomainNumericUpDown.Value = verticalPosition;
                horizontalDomainNumericUpDown.Value = horizontalPosition;

                Point result = new Point((int)horizontalPosition, (int)verticalPosition);
                return result;
            }
        }

        public bool LaserOn
        {
            get
            {
                return laserOnOffDomainSliderUserControl.DomainMinimumValue != laserOnOffDomainSliderUserControl.DomainValue;
            }
            set
            {
                if (value != LaserOn)
                    if (value)
                    {
                        laserOnOffDomainSliderUserControl.DomainValue = laserOnOffDomainSliderUserControl.DomainMaximumValue;
                        if (lastAnyControlKeyDown)
                            startPlayingLaserSound();
                    }
                    else
                    {
                        laserOnOffDomainSliderUserControl.DomainValue = laserOnOffDomainSliderUserControl.DomainMinimumValue;
                    }
            }
        }

        public void sendPololu(int servoPort, int servoPosition, int servoSpeed)
        {
            try
            {
                string comPort = comPortSettingsUserControl.SelectedComPort;
                int baudRate = comPortSettingsUserControl.SelectedBaudRate;
                servoController.Pololu(comPort, baudRate, servoPort, servoPosition, servoSpeed);
            }
            catch (Exception ex)
            {
                exceptionRichTextBox.Text = ex.ToString();
                exceptionRichTextBox.Visible = true;
            }
        }

        public void setLaser(int laserValue)
        {
            exceptionRichTextBox.Visible = false;
            int servoSpeed = 0; // always default speed!
            sendPololu(servoPortLaser, laserValue, servoSpeed);
        }

        private void targetPictureBox_Click(object sender, EventArgs e)
        {
            ShootAtCurrentPosition();
        }

        private void ShootAtCurrentPosition()
        {
            if (comPortSettingsUserControl.HasValidComPortSettings)
            {
                exceptionRichTextBox.Visible = false;
                Point shootPosition = ShootPosition;
                int servoSpeed = Convert.ToInt32(pololuSpeedDomainSliderUserControl.DomainValue);
                sendPololu(servoPortHorizontal, shootPosition.X, servoSpeed);
                sendPololu(servoPortVertical, shootPosition.Y, servoSpeed);
            }
        }

        private void targetPictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            int horizontal = targetPictureBox.Width - e.X; // invert horizontal
            int vertical = targetPictureBox.Height - e.Y; // invert vertical
            lastMouseDownLocation = new Point(horizontal, vertical);
        }

        private void targetPictureBox_DoubleClick(object sender, EventArgs e)
        {
            LaserOn = !LaserOn;
        }

        private void laserOnOffDomainSliderUserControl_DomainValueChanged(object sender, EventArgs e)
        {
            if (comPortSettingsUserControl.HasValidComPortSettings)
            {
                int laserValue = (int)(laserOnOffDomainSliderUserControl.DomainValue);
                setLaser(laserValue);
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            setLaser((int)(laserOnOffDomainSliderUserControl.DomainMinimumValue));
        }

        private void startPlayingLaserSound()
        {
            if (!playSoundBackgroundWorker.IsBusy)
                playSoundBackgroundWorker.RunWorkerAsync();
        }

        private void playSoundBackgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            // note: SoundPlayer can ONLY play PCM WAV files (no mp3, and no non-PCM WAV files)!
            using (System.Media.SoundPlayer soundPlayer = new System.Media.SoundPlayer("GunShot1.wav")) // TODO convert to const
            {
                soundPlayer.PlaySync();
            }
        }

        private void playSoundBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            LaserOn = false;
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            // in order to receive this event on the Form level, you must set KeyPreview = true;
            setLastAnyControlKeyDown();
        }

        private void MainForm_KeyUp(object sender, KeyEventArgs e)
        {
            // in order to receive this event on the Form level, you must set KeyPreview = true;
            setLastAnyControlKeyDown();
        }

        private void setLastAnyControlKeyDown()
        {
            lastAnyControlKeyDown = (ModifierKeys & Keys.Control) == Keys.Control;
        }

    }
}
