﻿using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
using System.Windows.Forms;

using AForge.Vision.Motion;
using System.Drawing;

namespace AForge.Vision.Local
{
    public partial class SelectMotionDetectionForm : Form
    {
        public SelectMotionDetectionForm()
        {
            InitializeComponent();
        }

        public MotionDetectorTypes MotionDetectorType
        {
            get
            {
                if (NoMotionDetectorRadioButton.Checked)
                    return MotionDetectorTypes.NoMotionDetector;
                if (TwoFramesDifferenceMotionDetectorRadioButton.Checked)
                    return MotionDetectorTypes.TwoFramesDifferenceMotionDetector;
                if (BackgroundModelingHighPrecisionMotionDetectorRadioButton.Checked)
                    return MotionDetectorTypes.BackgroundModelingHighPrecisionMotionDetector;
                if (BackgroundModelingLowPrecisionMotionDetectorRadioButton.Checked)
                    return MotionDetectorTypes.BackgroundModelingLowPrecisionMotionDetector;
                if (CountingMotionDetectorRadioButton.Checked)
                    return MotionDetectorTypes.CountingMotionDetector;
                return MotionDetectorTypes.NoMotionDetector;
            }
        }

        public bool HighlightMotionRegions
        {
            get { return highlightMotionRegionsCheckBox.Checked; }
            set { highlightMotionRegionsCheckBox.Checked = value; }
        }       

        public virtual IMotionDetector CreateMotionDetector()
        {
            switch (MotionDetectorType)
            {
                case MotionDetectorTypes.NoMotionDetector:
                    return null;
                case MotionDetectorTypes.TwoFramesDifferenceMotionDetector:
                    return new TwoFramesDifferenceMotionDetector(HighlightMotionRegions, true);
                case MotionDetectorTypes.BackgroundModelingHighPrecisionMotionDetector:
                    return new BackgroundModelingHighPrecisionMotionDetector(HighlightMotionRegions, true);
                case MotionDetectorTypes.BackgroundModelingLowPrecisionMotionDetector:
                    return new BackgroundModelingLowPrecisionMotionDetector(HighlightMotionRegions);
                case MotionDetectorTypes.CountingMotionDetector:
                    CountingMotionDetector result = new CountingMotionDetector(HighlightMotionRegions);
                    result.DifferenceThreshold = (int)(differenceThresholdDomainSliderUserControl.DomainValue);
                    return result;
            }
            return null;
        }

    }

    public enum MotionDetectorTypes
    {
        NoMotionDetector,
        TwoFramesDifferenceMotionDetector,
        BackgroundModelingHighPrecisionMotionDetector,
        BackgroundModelingLowPrecisionMotionDetector,
        CountingMotionDetector,
    }
}
