﻿namespace AForge.Vision.Local
{
    partial class SelectMotionDetectionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.highlightMotionRegionsCheckBox = new System.Windows.Forms.CheckBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CountingMotionDetectorRadioButton = new System.Windows.Forms.RadioButton();
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton = new System.Windows.Forms.RadioButton();
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton = new System.Windows.Forms.RadioButton();
            this.TwoFramesDifferenceMotionDetectorRadioButton = new System.Windows.Forms.RadioButton();
            this.NoMotionDetectorRadioButton = new System.Windows.Forms.RadioButton();
            this.differenceThresholdDomainSliderUserControl = new bo.Windows.Forms.UserControls.DomainSliderUserControl();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // highlightMotionRegionsCheckBox
            // 
            this.highlightMotionRegionsCheckBox.AutoSize = true;
            this.highlightMotionRegionsCheckBox.Checked = true;
            this.highlightMotionRegionsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.highlightMotionRegionsCheckBox.Location = new System.Drawing.Point(18, 156);
            this.highlightMotionRegionsCheckBox.Name = "highlightMotionRegionsCheckBox";
            this.highlightMotionRegionsCheckBox.Size = new System.Drawing.Size(144, 17);
            this.highlightMotionRegionsCheckBox.TabIndex = 1;
            this.highlightMotionRegionsCheckBox.Text = "&Highlight Motion Regions";
            this.highlightMotionRegionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancelButton.Location = new System.Drawing.Point(325, 261);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 3;
            this.cancelButton.Text = "Cancel";
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.okButton.Location = new System.Drawing.Point(235, 261);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 2;
            this.okButton.Text = "Ok";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CountingMotionDetectorRadioButton);
            this.groupBox1.Controls.Add(this.BackgroundModelingLowPrecisionMotionDetectorRadioButton);
            this.groupBox1.Controls.Add(this.BackgroundModelingHighPrecisionMotionDetectorRadioButton);
            this.groupBox1.Controls.Add(this.TwoFramesDifferenceMotionDetectorRadioButton);
            this.groupBox1.Controls.Add(this.NoMotionDetectorRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(388, 138);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Motion Detection Algorithm:";
            // 
            // CountingMotionDetectorRadioButton
            // 
            this.CountingMotionDetectorRadioButton.AutoSize = true;
            this.CountingMotionDetectorRadioButton.Checked = true;
            this.CountingMotionDetectorRadioButton.Location = new System.Drawing.Point(6, 111);
            this.CountingMotionDetectorRadioButton.Name = "CountingMotionDetectorRadioButton";
            this.CountingMotionDetectorRadioButton.Size = new System.Drawing.Size(76, 17);
            this.CountingMotionDetectorRadioButton.TabIndex = 4;
            this.CountingMotionDetectorRadioButton.TabStop = true;
            this.CountingMotionDetectorRadioButton.Text = "&4 Counting";
            this.CountingMotionDetectorRadioButton.UseVisualStyleBackColor = true;
            // 
            // BackgroundModelingLowPrecisionMotionDetectorRadioButton
            // 
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.AutoSize = true;
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.Location = new System.Drawing.Point(6, 88);
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.Name = "BackgroundModelingLowPrecisionMotionDetectorRadioButton";
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.Size = new System.Drawing.Size(207, 17);
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.TabIndex = 3;
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.Text = "&3 Background Modeling Low Precision";
            this.BackgroundModelingLowPrecisionMotionDetectorRadioButton.UseVisualStyleBackColor = true;
            // 
            // BackgroundModelingHighPrecisionMotionDetectorRadioButton
            // 
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.AutoSize = true;
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.Location = new System.Drawing.Point(6, 65);
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.Name = "BackgroundModelingHighPrecisionMotionDetectorRadioButton";
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.Size = new System.Drawing.Size(209, 17);
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.TabIndex = 2;
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.Text = "&2 Background Modeling High Precision";
            this.BackgroundModelingHighPrecisionMotionDetectorRadioButton.UseVisualStyleBackColor = true;
            // 
            // TwoFramesDifferenceMotionDetectorRadioButton
            // 
            this.TwoFramesDifferenceMotionDetectorRadioButton.AutoSize = true;
            this.TwoFramesDifferenceMotionDetectorRadioButton.Location = new System.Drawing.Point(6, 42);
            this.TwoFramesDifferenceMotionDetectorRadioButton.Name = "TwoFramesDifferenceMotionDetectorRadioButton";
            this.TwoFramesDifferenceMotionDetectorRadioButton.Size = new System.Drawing.Size(144, 17);
            this.TwoFramesDifferenceMotionDetectorRadioButton.TabIndex = 1;
            this.TwoFramesDifferenceMotionDetectorRadioButton.Text = "&1 Two Frames Difference";
            this.TwoFramesDifferenceMotionDetectorRadioButton.UseVisualStyleBackColor = true;
            // 
            // NoMotionDetectorRadioButton
            // 
            this.NoMotionDetectorRadioButton.AutoSize = true;
            this.NoMotionDetectorRadioButton.Location = new System.Drawing.Point(6, 19);
            this.NoMotionDetectorRadioButton.Name = "NoMotionDetectorRadioButton";
            this.NoMotionDetectorRadioButton.Size = new System.Drawing.Size(60, 17);
            this.NoMotionDetectorRadioButton.TabIndex = 0;
            this.NoMotionDetectorRadioButton.Text = "&0 None";
            this.NoMotionDetectorRadioButton.UseVisualStyleBackColor = true;
            // 
            // differenceThresholdDomainSliderUserControl
            // 
            this.differenceThresholdDomainSliderUserControl.DomainDescription = "Difference Threshold";
            this.differenceThresholdDomainSliderUserControl.DomainInitialValue = ((long)(100));
            this.differenceThresholdDomainSliderUserControl.DomainMaximumValue = ((long)(255));
            this.differenceThresholdDomainSliderUserControl.DomainMinimumValue = ((long)(0));
            this.differenceThresholdDomainSliderUserControl.DomainName = "Domain";
            this.differenceThresholdDomainSliderUserControl.DomainValue = ((long)(100));
            this.differenceThresholdDomainSliderUserControl.Location = new System.Drawing.Point(12, 179);
            this.differenceThresholdDomainSliderUserControl.Name = "differenceThresholdDomainSliderUserControl";
            this.differenceThresholdDomainSliderUserControl.Size = new System.Drawing.Size(174, 105);
            this.differenceThresholdDomainSliderUserControl.TabIndex = 4;
            // 
            // SelectMotionDetectionForm
            // 
            this.AcceptButton = this.okButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.cancelButton;
            this.ClientSize = new System.Drawing.Size(414, 296);
            this.Controls.Add(this.differenceThresholdDomainSliderUserControl);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.highlightMotionRegionsCheckBox);
            this.Name = "SelectMotionDetectionForm";
            this.Text = "AForge";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox highlightMotionRegionsCheckBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton CountingMotionDetectorRadioButton;
        private System.Windows.Forms.RadioButton BackgroundModelingLowPrecisionMotionDetectorRadioButton;
        private System.Windows.Forms.RadioButton BackgroundModelingHighPrecisionMotionDetectorRadioButton;
        private System.Windows.Forms.RadioButton TwoFramesDifferenceMotionDetectorRadioButton;
        private System.Windows.Forms.RadioButton NoMotionDetectorRadioButton;
        private bo.Windows.Forms.UserControls.DomainSliderUserControl differenceThresholdDomainSliderUserControl;
    }
}