﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using bo.IO.Ports;
using bo.IO.Pololu;

namespace bo.Windows.Forms.UserControls
{
    public partial class ComPortSettingsUserControl : UserControl
    {
        public ComPortSettingsUserControl()
        {
            InitializeComponent();
            fillBaudRateComboBox();
            fillComPortComboBox();
        }

        private void fillBaudRateComboBox()
        {
            baudRateComboBox.Items.Clear();
            int[] baudrates = new int[] { 2400, 4800, 9600, 14400, 19200, 28800, 38400, 57600 };
            foreach (int baudrate in baudrates)
            {
                baudRateComboBox.Items.Add(baudrate);
            }
            baudRateComboBox.SelectedIndex = 2;
        }

        private void fillComPortComboBox()
        {
            comPortComboBox.SelectedText = "";
            comPortComboBox.Items.Clear();
            if (onlyUsbDevicesCheckBox.Checked)
            {
                List<PololuSerialPortDevice> pololuSerialPortDevices = 
                    PololuSerialPortDevice.GetPololuSerialPortDevices();
                foreach (PololuSerialPortDevice pololuSerialPortDevice in pololuSerialPortDevices)
                {
                    SerialPortDeviceDisplayMemberWrapper<PololuSerialPortDevice> serialPortDeviceDisplayMemberWrapper =
                        new SerialPortDeviceDisplayMemberWrapper<PololuSerialPortDevice>
                            (pololuSerialPortDevice);
                    comPortComboBox.Items.Add(serialPortDeviceDisplayMemberWrapper);
                }
            }
            else
            {
                List<SerialPortDevice> serialPortDevices = 
                    PololuSerialPortDevice.GetSerialPortDevices();
                foreach (SerialPortDevice serialPortDevice in serialPortDevices)
                {
                    SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> serialPortDeviceDisplayMemberWrapper =
                        new SerialPortDeviceDisplayMemberWrapper<SerialPortDevice>
                            (serialPortDevice);
                    comPortComboBox.Items.Add(serialPortDeviceDisplayMemberWrapper);
                }
            }
            if (0 < comPortComboBox.Items.Count)
                comPortComboBox.SelectedIndex = comPortComboBox.Items.Count - 1;
            else
                comPortComboBox.SelectedIndex = -1; // disable the rest of the user interface !?
        }

        private int selectedBaudRate()
        {
            object baudRate = baudRateComboBox.SelectedItem;
            int result = (int)baudRate;
            return result;
        }

        private string selectedComPort()
        {
            object selectedItem = comPortComboBox.SelectedItem;
            {
                SerialPortDeviceDisplayMemberWrapper<SerialPortDevice> serialPortDeviceWrapper =
                    selectedItem as SerialPortDeviceDisplayMemberWrapper<SerialPortDevice>;
                if (null != serialPortDeviceWrapper)
                    return serialPortDeviceWrapper.Device.PortName;
            }
            {
                SerialPortDeviceDisplayMemberWrapper<PololuSerialPortDevice> serialPortDeviceWrapper =
                    selectedItem as SerialPortDeviceDisplayMemberWrapper<PololuSerialPortDevice>;
                if (null != serialPortDeviceWrapper)
                    return serialPortDeviceWrapper.Device.PortName;
            }
            return "";
        }

        public int SelectedBaudRate
        {
            get
            {
                return selectedBaudRate();
            }
        }

        public string SelectedComPort
        {
            get
            {
                return selectedComPort();
            }
        }

        public bool HasValidComPortSettings
        {
            get
            {
                bool result = !string.IsNullOrEmpty(SelectedComPort);
                return result;
            }
        }

        private void onlyUsbDevicesCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            fillComPortComboBox();
        }

        private void refreshPortListButton_Click(object sender, EventArgs e)
        {
            fillComPortComboBox();
        }

    }
}
