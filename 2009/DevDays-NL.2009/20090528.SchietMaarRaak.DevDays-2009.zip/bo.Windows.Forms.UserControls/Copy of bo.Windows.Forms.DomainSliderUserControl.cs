﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace bo.Windows.Forms.UserControls
{
    public partial class bo : UserControl
    {
        public bo()
        {
            InitializeComponent();
        }
    }
}
