using System;
using System.Windows.Forms;

namespace bo.Windows.Forms.UserControls
{
    public partial class DomainSliderUserControl : UserControl
    {
        public DomainSliderUserControl()
        {
            InitializeComponent();
            m_DomainDescription = "Domain Description";
            m_DomainName = "Domain";
            m_DomainMaximumValue = 10000;
            m_DomainMinimumValue = -1000;
            domainNumericUpDown.Minimum = DomainMinimumValue;
            domainNumericUpDown.Maximum = DomainMaximumValue;
            m_DomainInitialValue = 100;
            m_DomainValue = 1000;
        }

        #region properties and property members

        private string m_DomainDescription;
        public string DomainDescription
        {
            get { return m_DomainDescription; }
            set
            {
                if (DomainDescription != value)
                {
                    m_DomainDescription = value;
                    OnDomainDescriptionchanged();
                }
            }
        }

        private long m_DomainInitialValue;
        public long DomainInitialValue
        {
            get { return m_DomainInitialValue; }
            set
            {
                if (DomainInitialValue != value)
                {
                    m_DomainInitialValue = value;
                    DoDomainInitialValueChanged();
                }
            }
        }

        private long m_DomainMinimumValue;
        public long DomainMinimumValue
        {
            get { return m_DomainMinimumValue; }
            set
            {
                if (DomainMinimumValue != value)
                {
                    m_DomainMinimumValue = value;
                    domainNumericUpDown.Minimum = value;
                    OnDomainMinimumValueChanged();
                }
            }
        }

        private long m_DomainMaximumValue;
        public long DomainMaximumValue
        {
            get { return m_DomainMaximumValue; }
            set
            {
                if (DomainMaximumValue != value)
                {
                    m_DomainMaximumValue = value;
                    domainNumericUpDown.Maximum = value;
                    OnDomainMaximumValueChanged();
                }
            }
        }

        private string m_DomainName;
        public string DomainName
        {
            get { return m_DomainName; }
            set
            {
                if (DomainName != value)
                {
                    m_DomainName = value;
                    OnDomainNameChanged();
                }
            }
        }

        private long m_DomainValue;
        public long DomainValue
        {
            get { return m_DomainValue; }
            set
            {
                if (DomainValue != value)
                {
                    m_DomainValue = value;
                    OnDomainValueChanged();
                }
            }
        }

        #endregion

        #region property changed methods

        protected virtual void OnDomainDescriptionchanged()
        {
            DomainGroupBox.Text = DomainDescription + ':';
        }

        private void DoDomainInitialValueChanged()
        {
            DomainValue = DomainInitialValue;
            UpdateResetToInitialValueButton();
        }

        private void OnDomainMaximumValueChanged()
        {
            domainMaximumLabel.Text = DomainMaximumValue.ToString();
            domainNumericUpDown.Maximum = DomainMaximumValue;
            // HACK: TrackBar bug workaround
            if (DomainValue > DomainMaximumValue)
            {
                DomainValue = DomainMaximumValue;
            }
            else
            {
                ExtrapolateDomainTrackBarValue();
            }
        }

        protected virtual void OnDomainMinimumValueChanged()
        {
            domainMinimumLabel.Text = DomainMinimumValue.ToString();
            domainNumericUpDown.Minimum = DomainMinimumValue;
            // HACK: TrackBar bug workaround
            if (DomainValue < DomainMinimumValue)
            {
                DomainValue = DomainMinimumValue;
            }
            else
            {
                ExtrapolateDomainTrackBarValue();
            }
        }

        protected virtual void OnDomainNameChanged()
        {
            UpdateResetToInitialValueButton();
        }

        private bool m_DomainValueChangedInProgress = false;
        protected virtual void OnDomainValueChanged()
        {
            bool old_m_DomainValueChangedInProgress = m_DomainValueChangedInProgress;
            m_DomainValueChangedInProgress = true;
            try
            {
                domainNumericUpDown.Value = DomainValue;
                ExtrapolateDomainTrackBarValue();
                if (null != DomainValueChanged)
                {
                    DomainValueChanged(this, new EventArgs());
                }
            }
            finally
            {
                m_DomainValueChangedInProgress = old_m_DomainValueChangedInProgress;
            }
        }

        bool m_ExtrapolateDomainTrackBarValueInProgress = false;
        private void ExtrapolateDomainTrackBarValue()
        {
            bool oldm_ExtrapolateDomainTrackBarValueInProgress = m_ExtrapolateDomainTrackBarValueInProgress;
            m_ExtrapolateDomainTrackBarValueInProgress = true;
            try
            {
                //domainTrackBar.Value = DomainValue;
                // HACK: TrackBar bug workaround - TrackBar uses 4 bytes of memory for each value of Maximum that gets incremented
                // we work around this by using a standard trackbar (that uses only 400 bytes of extra memory)
                // and extrapolating from there.
                Int64 MinMaxRange = DomainMaximumValue - DomainMinimumValue;
                if (0 != MinMaxRange)
                {
                    Int64 ExtrapolatedValue = DomainValue - DomainMinimumValue; // correct for the origin
                    ExtrapolatedValue = ExtrapolatedValue * domainTrackBar.Maximum; // correct for the scale
                    ExtrapolatedValue = ExtrapolatedValue / MinMaxRange;
                    domainTrackBar.Value = Convert.ToInt32(ExtrapolatedValue);
                }
            }
            finally
            {
                m_ExtrapolateDomainTrackBarValueInProgress = oldm_ExtrapolateDomainTrackBarValueInProgress;
            }
        }

        #endregion

        #region events

        public event EventHandler DomainValueChanged;

        #endregion

        #region update UI

        private void UpdateResetToInitialValueButton()
        {
            resetToInitialDomainValueButton.Text =
                //string.Format("Reset {0} to {1}", DomainName, DomainInitialValue);
                string.Format("Reset {0}", DomainName);
        }

        private void UpdateTrackBarTickFrequency()
        {
            long frequencyRange = DomainMaximumValue - DomainMinimumValue;
            if (frequencyRange < 0)
            {
                frequencyRange = -frequencyRange;
            }

            int tickFrequency = 1;
            while (frequencyRange > tickFrequency * 1000)
            {
                tickFrequency = tickFrequency * 10;
            }
            int domainTrackBarSize = (domainTrackBar.Orientation == Orientation.Horizontal) ?
                domainTrackBar.Width : domainTrackBar.Height;

            // make sure the ticks on the TrackBar are in fact visible, so there should be no more ticks than the TrackBar size

            long ticksPerTrackBar = frequencyRange / tickFrequency;
            while (ticksPerTrackBar > domainTrackBarSize)
            {
                tickFrequency = tickFrequency * 10;
                ticksPerTrackBar = frequencyRange / tickFrequency;
            }

            domainTrackBar.TickFrequency = tickFrequency;
            domainTrackBar.LargeChange = tickFrequency * 10;
        }

        #endregion

        #region event methods

        private void resetToInitialDomainValueButton_Click(object sender, EventArgs e)
        {
            DomainValue = DomainInitialValue;
        }

        private void domainNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            DomainValue = Convert.ToInt32(domainNumericUpDown.Value);
        }

        #endregion

        private void domainTrackBar_ValueChanged(object sender, EventArgs e)
        {
            if (!(m_DomainValueChangedInProgress || m_ExtrapolateDomainTrackBarValueInProgress))
            {
                // HACK: TrackBar bug workaround - TrackBar uses 4 bytes of memory for each value of Maximum that gets incremented
                // we work around this by using a standard trackbar (that uses only 400 bytes of extra memory)
                // and extrapolating from there.
                //DomainValue = domainTrackBar.Value; // this would be without extrapolating
                Int64 MinMaxRange = DomainMaximumValue - DomainMinimumValue;
                Int64 ExtrapolatedValue = domainTrackBar.Value * MinMaxRange;
                ExtrapolatedValue = ExtrapolatedValue / domainTrackBar.Maximum; // correct for the scale
                ExtrapolatedValue = ExtrapolatedValue + DomainMinimumValue; // correct for the origin
                DomainValue = Convert.ToInt32(ExtrapolatedValue);
            }
        }

    }
}
