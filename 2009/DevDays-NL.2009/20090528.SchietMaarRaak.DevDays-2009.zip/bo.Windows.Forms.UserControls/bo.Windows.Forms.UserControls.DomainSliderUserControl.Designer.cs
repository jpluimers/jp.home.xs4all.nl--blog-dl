namespace bo.Windows.Forms.UserControls
{
    partial class DomainSliderUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DomainGroupBox = new System.Windows.Forms.GroupBox();
            this.domainNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.resetToInitialDomainValueButton = new System.Windows.Forms.Button();
            this.domainTrackBar = new System.Windows.Forms.TrackBar();
            this.domainMaximumLabel = new System.Windows.Forms.Label();
            this.domainMinimumLabel = new System.Windows.Forms.Label();
            this.DomainGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.domainNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // DomainGroupBox
            // 
            this.DomainGroupBox.Controls.Add(this.domainMaximumLabel);
            this.DomainGroupBox.Controls.Add(this.domainMinimumLabel);
            this.DomainGroupBox.Controls.Add(this.domainNumericUpDown);
            this.DomainGroupBox.Controls.Add(this.resetToInitialDomainValueButton);
            this.DomainGroupBox.Controls.Add(this.domainTrackBar);
            this.DomainGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DomainGroupBox.Location = new System.Drawing.Point(0, 0);
            this.DomainGroupBox.Name = "DomainGroupBox";
            this.DomainGroupBox.Size = new System.Drawing.Size(337, 105);
            this.DomainGroupBox.TabIndex = 11;
            this.DomainGroupBox.TabStop = false;
            this.DomainGroupBox.Text = "Domain description:";
            // 
            // domainNumericUpDown
            // 
            this.domainNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.domainNumericUpDown.Location = new System.Drawing.Point(66, 49);
            this.domainNumericUpDown.Name = "domainNumericUpDown";
            this.domainNumericUpDown.ReadOnly = true;
            this.domainNumericUpDown.Size = new System.Drawing.Size(214, 20);
            this.domainNumericUpDown.TabIndex = 11;
            this.domainNumericUpDown.ValueChanged += new System.EventHandler(this.domainNumericUpDown_ValueChanged);
            // 
            // resetToInitialDomainValueButton
            // 
            this.resetToInitialDomainValueButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.resetToInitialDomainValueButton.Location = new System.Drawing.Point(66, 74);
            this.resetToInitialDomainValueButton.Name = "resetToInitialDomainValueButton";
            this.resetToInitialDomainValueButton.Size = new System.Drawing.Size(214, 23);
            this.resetToInitialDomainValueButton.TabIndex = 10;
            this.resetToInitialDomainValueButton.Text = "&Initial value";
            this.resetToInitialDomainValueButton.UseVisualStyleBackColor = true;
            this.resetToInitialDomainValueButton.Click += new System.EventHandler(this.resetToInitialDomainValueButton_Click);
            // 
            // domainTrackBar
            // 
            this.domainTrackBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.domainTrackBar.Location = new System.Drawing.Point(6, 15);
            this.domainTrackBar.Maximum = 100;
            this.domainTrackBar.Name = "domainTrackBar";
            this.domainTrackBar.Size = new System.Drawing.Size(325, 42);
            this.domainTrackBar.TabIndex = 5;
            this.domainTrackBar.TickFrequency = 10;
            this.domainTrackBar.ValueChanged += new System.EventHandler(this.domainTrackBar_ValueChanged);
            // 
            // domainMaximumLabel
            // 
            this.domainMaximumLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.domainMaximumLabel.Location = new System.Drawing.Point(279, 51);
            this.domainMaximumLabel.Name = "domainMaximumLabel";
            this.domainMaximumLabel.Size = new System.Drawing.Size(54, 23);
            this.domainMaximumLabel.TabIndex = 9;
            this.domainMaximumLabel.Text = "1234567";
            this.domainMaximumLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // domainMinimumLabel
            // 
            this.domainMinimumLabel.Location = new System.Drawing.Point(6, 51);
            this.domainMinimumLabel.Name = "domainMinimumLabel";
            this.domainMinimumLabel.Size = new System.Drawing.Size(54, 23);
            this.domainMinimumLabel.TabIndex = 8;
            this.domainMinimumLabel.Text = "1234567";
            // 
            // DomainSliderUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.DomainGroupBox);
            this.Name = "DomainSliderUserControl";
            this.Size = new System.Drawing.Size(337, 105);
            this.DomainGroupBox.ResumeLayout(false);
            this.DomainGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.domainNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.domainTrackBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox DomainGroupBox;
        private System.Windows.Forms.Button resetToInitialDomainValueButton;
        private System.Windows.Forms.TrackBar domainTrackBar;
        private System.Windows.Forms.Label domainMaximumLabel;
        private System.Windows.Forms.Label domainMinimumLabel;
        private System.Windows.Forms.NumericUpDown domainNumericUpDown;
    }
}
