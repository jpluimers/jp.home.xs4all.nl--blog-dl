﻿namespace bo.Windows.Forms.UserControls
{
    partial class ComPortSettingsUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxComm = new System.Windows.Forms.GroupBox();
            this.refreshPortListButton = new System.Windows.Forms.Button();
            this.onlyUsbDevicesCheckBox = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comPortComboBox = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.baudRateComboBox = new System.Windows.Forms.ComboBox();
            this.groupBoxComm.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxComm
            // 
            this.groupBoxComm.Controls.Add(this.refreshPortListButton);
            this.groupBoxComm.Controls.Add(this.onlyUsbDevicesCheckBox);
            this.groupBoxComm.Controls.Add(this.label3);
            this.groupBoxComm.Controls.Add(this.comPortComboBox);
            this.groupBoxComm.Controls.Add(this.label4);
            this.groupBoxComm.Controls.Add(this.baudRateComboBox);
            this.groupBoxComm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxComm.Location = new System.Drawing.Point(0, 0);
            this.groupBoxComm.Name = "groupBoxComm";
            this.groupBoxComm.Size = new System.Drawing.Size(376, 108);
            this.groupBoxComm.TabIndex = 4;
            this.groupBoxComm.TabStop = false;
            this.groupBoxComm.Text = "Comm. Settings";
            // 
            // refreshPortListButton
            // 
            this.refreshPortListButton.Location = new System.Drawing.Point(240, 15);
            this.refreshPortListButton.Name = "refreshPortListButton";
            this.refreshPortListButton.Size = new System.Drawing.Size(103, 23);
            this.refreshPortListButton.TabIndex = 5;
            this.refreshPortListButton.Text = "&Refresh port list";
            this.refreshPortListButton.UseVisualStyleBackColor = true;
            this.refreshPortListButton.Click += new System.EventHandler(this.refreshPortListButton_Click);
            // 
            // onlyUsbDevicesCheckBox
            // 
            this.onlyUsbDevicesCheckBox.AutoSize = true;
            this.onlyUsbDevicesCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.onlyUsbDevicesCheckBox.Checked = true;
            this.onlyUsbDevicesCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.onlyUsbDevicesCheckBox.Location = new System.Drawing.Point(6, 19);
            this.onlyUsbDevicesCheckBox.Name = "onlyUsbDevicesCheckBox";
            this.onlyUsbDevicesCheckBox.Size = new System.Drawing.Size(112, 17);
            this.onlyUsbDevicesCheckBox.TabIndex = 0;
            this.onlyUsbDevicesCheckBox.Text = "Only USB devices";
            this.onlyUsbDevicesCheckBox.UseVisualStyleBackColor = true;
            this.onlyUsbDevicesCheckBox.CheckedChanged += new System.EventHandler(this.onlyUsbDevicesCheckBox_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 45);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "COM Port:";
            // 
            // comPortComboBox
            // 
            this.comPortComboBox.FormattingEnabled = true;
            this.comPortComboBox.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "COM10"});
            this.comPortComboBox.Location = new System.Drawing.Point(102, 42);
            this.comPortComboBox.Name = "comPortComboBox";
            this.comPortComboBox.Size = new System.Drawing.Size(241, 21);
            this.comPortComboBox.TabIndex = 2;
            this.comPortComboBox.Text = "COM3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Baud Rate";
            // 
            // baudRateComboBox
            // 
            this.baudRateComboBox.FormattingEnabled = true;
            this.baudRateComboBox.Items.AddRange(new object[] {
            "9600",
            "14400",
            "19200",
            "28800",
            "38400",
            "57600"});
            this.baudRateComboBox.Location = new System.Drawing.Point(102, 69);
            this.baudRateComboBox.Name = "baudRateComboBox";
            this.baudRateComboBox.Size = new System.Drawing.Size(63, 21);
            this.baudRateComboBox.TabIndex = 4;
            this.baudRateComboBox.Text = "9600";
            // 
            // bo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBoxComm);
            this.Name = "bo";
            this.Size = new System.Drawing.Size(376, 108);
            this.groupBoxComm.ResumeLayout(false);
            this.groupBoxComm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxComm;
        private System.Windows.Forms.Button refreshPortListButton;
        private System.Windows.Forms.CheckBox onlyUsbDevicesCheckBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comPortComboBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox baudRateComboBox;
    }
}
